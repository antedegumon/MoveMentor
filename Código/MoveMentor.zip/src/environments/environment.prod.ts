export const environment = {
  production: true,
  apiUrl:'http:200.128.151.43//:8087'
};
