import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'tabs/inicio',
    pathMatch: 'full'
  },
  {
    path: '',
    loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'inicio',
    loadChildren: () => import('./pages/inicio/inicio.module').then( m => m.InicioPageModule)
  },
  {
    path: 'dados',
    loadChildren: () => import('./pages/dados/dados.module').then( m => m.DadosPageModule)
  },
  {
    path: 'treinos',
    loadChildren: () => import('./pages/treinos/treinos.module').then( m => m.TreinosPageModule)
  },
  {
    path: 'corridas',
    loadChildren: () => import('./pages/corridas/corridas.module').then( m => m.CorridasPageModule)
  },
  {
    path: 'fichas',
    loadChildren: () => import('./pages/fichas/fichas.module').then( m => m.FichasPageModule)
  },
  {
    path: 'treino-add',
    loadChildren: () => import('./pages/treino-add/treino-add.module').then( m => m.TreinoAddPageModule)
  },
  {
    path: 'treino-add/:id',
    loadChildren: () => import('./pages/treino-add/treino-add.module').then( m => m.TreinoAddPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'login/:reload',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'cadastro',
    loadChildren: () => import('./pages/cadastro/cadastro.module').then( m => m.CadastroPageModule)
  },
  {
    path: 'cadastro/:idUsuario',
    loadChildren: () => import('./pages/cadastro/cadastro.module').then( m => m.CadastroPageModule)
  },
  {
    path: 'ficha-add',
    loadChildren: () => import('./pages/ficha-add/ficha-add.module').then( m => m.FichaAddPageModule)
  },
  {
    path: 'cad-dados',
    loadChildren: () => import('./pages/cad-dados/cad-dados.module').then( m => m.CadDadosPageModule)
  },
  {
    path: 'cad-dados/:id',
    loadChildren: () => import('./pages/cad-dados/cad-dados.module').then( m => m.CadDadosPageModule)
  },
  {
    path: 'exercicio-info',
    loadChildren: () => import('./pages/exercicio-info/exercicio-info.module').then( m => m.ExercicioInfoPageModule)
  },
  {
    path: 'alerta',
    loadChildren: () => import('./pages/alerta/alerta.module').then( m => m.AlertaPageModule)
  },
  {
    path: 'alerta/:id',
    loadChildren: () => import('./pages/alerta/alerta.module').then( m => m.AlertaPageModule)
  },
  {
    path: 'corrida-start',
    loadChildren: () => import('./pages/corrida-start/corrida-start.module').then( m => m.CorridaStartPageModule)
  },
  {
    path: 'corrida-start/:id',
    loadChildren: () => import('./pages/corrida-start/corrida-start.module').then( m => m.CorridaStartPageModule)
  },
  {
    path: 'listadados',
    loadChildren: () => import('./pages/listadados/listadados.module').then( m => m.ListadadosPageModule)
  },
  {
    path: 'listadados/:id',
    loadChildren: () => import('./pages/listadados/listadados.module').then( m => m.ListadadosPageModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
