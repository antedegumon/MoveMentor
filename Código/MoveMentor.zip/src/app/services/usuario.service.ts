import { Injectable } from '@angular/core';
import { Usuario } from '../model/usuario';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  
 
  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }
  
  
  //url: string = 'https://cors-anywhere.herokuapp.com/https://movementor.free.nf/usuario';
  //url: string = 'https://movementor.free.nf/usuario';
  //url: string = 'http://localhost:8087/movementor/usuario';
  url: string = 'https://teal-mink-565589.hostingersite.com/usuario';


  constructor(private httpClient: HttpClient,) { }

  async salvar(usuario: Usuario): Promise<Usuario> {
    console.log(usuario);
    return await firstValueFrom(
      this.httpClient.post<Usuario>(this.url, usuario, this.httpHeaders)
    );
  }

  async atualizar(usuario: Usuario): Promise<Usuario> {
    return await firstValueFrom(this.httpClient.put<Usuario>(this.url, JSON.stringify(usuario), this.httpHeaders));
  }

  async listar(): Promise<Usuario[]> {
    return await firstValueFrom(this.httpClient.get<Usuario[]>(this.url));
  }

  async buscarPorId(id: number): Promise<Usuario> {
    let urlAuxiliar = this.url + "/byid/" + id;
    return await firstValueFrom(this.httpClient.get<Usuario>(urlAuxiliar));
  }

  async excluir(id: number): Promise<Usuario> {
    let urlAuxiliar = this.url + "/" + id;
    return await firstValueFrom(this.httpClient.delete<Usuario>(urlAuxiliar));
  }

  async autenticar(login: string, senha: string): Promise<Usuario> {
    let urlAuxiliar = this.url + '/autenticar' + "/" + login + "/" + senha  ;
    console.log(urlAuxiliar);
    
    return await firstValueFrom(this.httpClient.get<Usuario>(urlAuxiliar));
    
  }

  async verificarLogin(login: string): Promise<boolean> {
    let urlAuxiliar = this.url + "/" + login + '/login/exists';
    return await firstValueFrom(this.httpClient.get<boolean>(urlAuxiliar));
  }

  registrarAutenticacao(usuario: Usuario) {
    localStorage.setItem('usuarioAutenticado', JSON.stringify(usuario));
  }

  recuperarAutenticacao(): Usuario {
    
    let usuario = new Usuario();
    usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "{}");
    return usuario;
  }

  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }
}