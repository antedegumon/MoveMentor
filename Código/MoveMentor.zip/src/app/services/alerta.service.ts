import { Injectable } from '@angular/core';
import { Alerta } from '../model/alerta';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AlertaService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/comentario';

  constructor(private httpClient: HttpClient) { }

  async salvar(alerta: Alerta): Promise<Alerta> {
    if (alerta.IDComentario === 0) {
      console.log(this.url, JSON.stringify(alerta), this.httpHeaders);
      return await firstValueFrom(this.httpClient.post<Alerta>(this.url, JSON.stringify(alerta), this.httpHeaders));
    } else {
      return await firstValueFrom(this.httpClient.put<Alerta>(this.url, JSON.stringify(alerta), this.httpHeaders));
    }
  }


  async buscarPorId(id: number): Promise<Alerta> {
    let urlAuxiliar = this.url + "/" + id;
    return await firstValueFrom(this.httpClient.get<Alerta>(urlAuxiliar));
  }

  async desativar(id: number): Promise<Alerta> {
    let urlAuxiliar = this.url + "/" + id +"/desativar";
    return await firstValueFrom(this.httpClient.put<Alerta>(urlAuxiliar, null ));
  }

  



 

 


  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }
}