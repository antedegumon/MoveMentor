import { TestBed } from '@angular/core/testing';

import { FichaexercicioService } from './fichaexercicio.service';

describe('FichaexercicioService', () => {
  let service: FichaexercicioService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FichaexercicioService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
