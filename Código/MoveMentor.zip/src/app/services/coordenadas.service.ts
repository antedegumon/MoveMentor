import { Injectable } from '@angular/core';
import { Coordenadas } from '../model/coordenadas';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CoordenadasService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/corridacoordenada';

  constructor(private httpClient: HttpClient) { }

  async salvar(coordenada: Coordenadas): Promise<Coordenadas> {
    if (coordenada.IDCoordenada === 0) {
      console.log(this.url, JSON.stringify(coordenada), this.httpHeaders);
      return await firstValueFrom(this.httpClient.post<Coordenadas>(this.url, JSON.stringify(coordenada), this.httpHeaders));
    } else {
      return await firstValueFrom(this.httpClient.put<Coordenadas>(this.url, JSON.stringify(coordenada), this.httpHeaders));
    }
  }

  async listar(id : number): Promise<Coordenadas[]> {
    let urlAuxiliar = this.url  +"/corrida/"+ id;
    console.log(urlAuxiliar);
    return await firstValueFrom(this.httpClient.get<Coordenadas[]>(urlAuxiliar));
  }

  async buscarPorId(id: number): Promise<Coordenadas> {
    let urlAuxiliar = this.url + "/" + id;
    return await firstValueFrom(this.httpClient.get<Coordenadas>(urlAuxiliar));
  }

  async desativar(id: number): Promise<Coordenadas> {
    let urlAuxiliar = this.url + "/" + id ;
    return await firstValueFrom(this.httpClient.delete<Coordenadas>(urlAuxiliar));
  }


  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }
}