import { Injectable } from '@angular/core';
import { Corrida } from '../model/corrida';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CorridaService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/corrida';

  constructor(private httpClient: HttpClient) { }

  async salvar(corrida: Corrida): Promise<Corrida> {
    console.log(corrida.IDCorrida);
    if (corrida.IDCorrida === 0) {
    
      return await firstValueFrom(this.httpClient.post<Corrida>(this.url, JSON.stringify(corrida), this.httpHeaders));
    } else {
      return await firstValueFrom(this.httpClient.put<Corrida>(this.url, JSON.stringify(corrida), this.httpHeaders));
    }
  }

  async listar(id : number): Promise<Corrida[]> {
    let urlAuxiliar = this.url  +"/usu/"+ id;
   
    return await firstValueFrom(this.httpClient.get<Corrida[]>(urlAuxiliar));
  }

  async buscarPorId(id: number): Promise<Corrida> {
    let urlAuxiliar = this.url + "/byid/" + id;
    return await firstValueFrom(this.httpClient.get<Corrida>(urlAuxiliar));
  }

  async buscarPorData(data: String, id: number): Promise<Corrida> {
    let urlAuxiliar = this.url + "/bydate/" + data + "/" + id;
    return await firstValueFrom(this.httpClient.get<Corrida>(urlAuxiliar));
  }

  async desativar(id: number): Promise<Corrida> {
    let urlAuxiliar = this.url + "/" + id ;
    return await firstValueFrom(this.httpClient.delete<Corrida>(urlAuxiliar ));
  }

  



 

 


  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }
}