import { TestBed } from '@angular/core/testing';

import { TreinoextraService } from './treinoextra.service';

describe('TreinoextraService', () => {
  let service: TreinoextraService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TreinoextraService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
