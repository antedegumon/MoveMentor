import { Injectable } from '@angular/core';
import { TreinoExtra } from '../model/treinoextra';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TreinoExtraService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/treinoextra';

  constructor(private httpClient: HttpClient) { }

  async salvar(treinoExtra: TreinoExtra): Promise<TreinoExtra> {
    
      return await firstValueFrom(this.httpClient.post<TreinoExtra>(this.url, JSON.stringify(treinoExtra), this.httpHeaders));
    
  }

  async listar(): Promise<TreinoExtra[]> {
    return await firstValueFrom(this.httpClient.get<TreinoExtra[]>(this.url));
  }

  async buscarPorId(id: number): Promise<TreinoExtra[]> {
    let urlAuxiliar = this.url + "/treino/" + id;
    return await firstValueFrom(this.httpClient.get<TreinoExtra[]>(urlAuxiliar));
  }


}