import { Injectable } from '@angular/core';
import { Exercicio } from '../model/exercicio';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ExercicioService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/exercicio';

  constructor(private httpClient: HttpClient) { }

  async salvar(exercicio: Exercicio): Promise<Exercicio> {
    if (exercicio.IDExercicio === 0) {
      return await firstValueFrom(this.httpClient.post<Exercicio>(this.url, JSON.stringify(exercicio), this.httpHeaders));
    } else {
      return await firstValueFrom(this.httpClient.put<Exercicio>(this.url, JSON.stringify(exercicio), this.httpHeaders));
    }
  }

  async listar(): Promise<Exercicio[]> {
    return await firstValueFrom(this.httpClient.get<Exercicio[]>(this.url));
  }

  async buscarPorId(id: number): Promise<Exercicio> {
    let urlAuxiliar = this.url + "/byid/" + id;
    return await firstValueFrom(this.httpClient.get<Exercicio>(urlAuxiliar));
  }

  async excluir(id: number): Promise<Exercicio> {
    let urlAuxiliar = this.url + "/" + id;
    return await firstValueFrom(this.httpClient.delete<Exercicio>(urlAuxiliar));
  }

  
  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }
}