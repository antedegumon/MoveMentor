import { Injectable } from '@angular/core';
import { Ficha } from '../model/ficha';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FichaService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/ficha';

  constructor(private httpClient: HttpClient) { }

  async salvar(ficha: Ficha): Promise<Ficha> {
    if (ficha.IDFicha === 0) {
      return await firstValueFrom(this.httpClient.post<Ficha>(this.url, JSON.stringify(ficha), this.httpHeaders));
    } else {
      return await firstValueFrom(this.httpClient.put<Ficha>(this.url, JSON.stringify(ficha), this.httpHeaders));
    }
  }

  async listar(): Promise<Ficha[]> {
    return await firstValueFrom(this.httpClient.get<Ficha[]>(this.url));
  }

  async listarPorUsuario(idUsuario: number): Promise<Ficha[]> {
    let urlAuxiliar = this.url + "/usu/" + idUsuario ;
    return await firstValueFrom(this.httpClient.get<Ficha[]>(urlAuxiliar));
  }
  
  async buscarPorId(id: number): Promise<Ficha> {
    let urlAuxiliar = this.url + "/byid/" + id;
    return await firstValueFrom(this.httpClient.get<Ficha>(urlAuxiliar));
  }

  async excluir(id: number): Promise<Ficha> {
    let urlAuxiliar = this.url + "/" + id;
    return await firstValueFrom(this.httpClient.delete<Ficha>(urlAuxiliar));
  }

  async desativar(id: number): Promise<Ficha> {
    let urlAuxiliar = this.url + "/" + id;
    return await firstValueFrom(this.httpClient.delete<Ficha>(urlAuxiliar));
  }
  



 

 


  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }
}