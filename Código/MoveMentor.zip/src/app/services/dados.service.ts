import { Injectable } from '@angular/core';
import { Dados } from '../model/dados';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DadosService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/dadoscorporais';

  constructor(private httpClient: HttpClient) { }

  async salvar(dados: Dados): Promise<Dados> {
    try {
      // Imprime os dados no console para depuração
      console.log(this.url, dados, this.httpHeaders);
  
      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
      });
  
      // Verifica se é um novo registro ou atualização
      if (dados.IDDadosCorporais === 0) {
        return await firstValueFrom(
          this.httpClient.post<Dados>(this.url, dados, { headers })
        );
      } else {
        return await firstValueFrom(
          this.httpClient.put<Dados>(this.url, dados, { headers })
        );
      }
    } catch (error) {
      console.error('Erro ao salvar dados:', error);
      throw error; // Re-throws the error for further handling
    }
  }

  async listar(id : number): Promise<Dados[]> {
    let urlAuxiliar = this.url  +"/usu/"+ id;
    console.log(urlAuxiliar);
    return await firstValueFrom(this.httpClient.get<Dados[]>(urlAuxiliar));
  }

  async buscarPorId(id: number): Promise<Dados> {
    let urlAuxiliar = this.url + "/byid/" + id;
    return await firstValueFrom(this.httpClient.get<Dados>(urlAuxiliar));
  }

  async desativar(id: number): Promise<Dados> {
    let urlAuxiliar = this.url + "/" + id ;
    return await firstValueFrom(this.httpClient.delete<Dados>(urlAuxiliar ));
  }

  



 

 


  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }
}