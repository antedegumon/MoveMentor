import { Injectable } from '@angular/core';
import { Treino } from '../model/treino';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TreinoService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/treino';

  constructor(private httpClient: HttpClient) { }

  async salvar(treino: Treino): Promise<Treino> {
    if (treino.IDTreino === 0) {
      console.log(this.url, JSON.stringify(treino), this.httpHeaders);
      return await firstValueFrom(this.httpClient.post<Treino>(this.url, JSON.stringify(treino), this.httpHeaders));
    } else {
      return await firstValueFrom(this.httpClient.put<Treino>(this.url, JSON.stringify(treino), this.httpHeaders));
    }
  }

  async listar(id : number): Promise<Treino[]> {
    let urlAuxiliar = this.url + "/usu/" + id;
    
    return await firstValueFrom(this.httpClient.get<Treino[]>(urlAuxiliar));
  }

  async buscarPorId(id: number): Promise<Treino> {
    let urlAuxiliar = this.url + "/byid/" + id;
    return await firstValueFrom(this.httpClient.get<Treino>(urlAuxiliar));
  }

  async buscarPorData(data: string, id : number): Promise<Treino> {
    let urlAuxiliar = this.url + "/bydate/" + data +"/"+id;
    
    return await firstValueFrom(this.httpClient.get<Treino>(urlAuxiliar));
  }

  async desativar(id: number): Promise<Treino> {
    let urlAuxiliar = this.url + "/" + id;
    return await firstValueFrom(this.httpClient.delete<Treino>(urlAuxiliar ));
  }

  encerrarAutenticacao() {
    localStorage.removeItem('usuarioAutenticado');
  }

  
}