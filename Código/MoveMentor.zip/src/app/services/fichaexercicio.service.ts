import { Injectable } from '@angular/core';
import { Fichaexercicio } from '../model/fichaexercicio';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FichaexercicioService {

  httpHeaders = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }

  url: string = 'https://teal-mink-565589.hostingersite.com/fichaexercicio';

  constructor(private httpClient: HttpClient) { }

  async salvar(fichaexercicio: Fichaexercicio): Promise<Fichaexercicio> {
    
      return await firstValueFrom(this.httpClient.post<Fichaexercicio>(this.url, JSON.stringify(fichaexercicio), this.httpHeaders));
    
  }

  async listar(): Promise<Fichaexercicio[]> {
    return await firstValueFrom(this.httpClient.get<Fichaexercicio[]>(this.url));
  }

  async buscarPorId(id: number): Promise<Fichaexercicio[]> {
    let urlAuxiliar = this.url + "/ficha/" + id;
    return await firstValueFrom(this.httpClient.get<Fichaexercicio[]>(urlAuxiliar));
  }


}