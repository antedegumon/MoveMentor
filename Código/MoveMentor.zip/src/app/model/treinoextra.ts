import { LocalTime } from '@js-joda/core';

export class TreinoExtra {

    IDExercicio: number;
    IDTreino: number;
    Situacao: boolean;
    Series: number;
    Repeticoes: number;
    Tempo!: LocalTime;
    Flag: boolean;

    constructor() {
        this.IDExercicio = 0;
        this.IDTreino = 0;
        this.Situacao=true;
        this.Series = 0;
        this.Repeticoes = 0;
        this.Flag = true;

        
    }

}
