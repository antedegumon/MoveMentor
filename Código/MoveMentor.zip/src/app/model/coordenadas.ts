import { LocalDate } from "@js-joda/core";

export class Coordenadas {

    IDCoordenada: number;
	IDCorrida: number;
	Ordem: number;
	Latitude: number;
	Longitude: number;
    
    constructor(idCorrida: number, latitude: number, longitude: number, ordem: number){
        this.IDCoordenada = 0;
        this.IDCorrida = idCorrida;
        this.Ordem = ordem;
        this.Latitude = latitude;
        this.Longitude = longitude;


    }

    

}
