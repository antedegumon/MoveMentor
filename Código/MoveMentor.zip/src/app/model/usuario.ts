export class Usuario {
    IDUsuario: number;
    Nome: string;
    Email: string;
    Senha: string;
    DataNascimento: string;
    Genero: string;
    Flag: number;

    constructor() {
        this.IDUsuario = 0;
        this.Nome = "";
        this.Email = "";
        this.Senha = "";
        this.DataNascimento = "";
        this.Genero = "";
        this.Flag = 1;
    }
}
