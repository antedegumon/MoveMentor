import { LocalTime } from '@js-joda/core';

export class Fichaexercicio {

    IDExercicio: number;
    IDFicha: number;
    Series: number;
    Repeticoes!: number;
    Tempo!: LocalTime;

    constructor() {
        this.IDExercicio = 0;
        this.IDFicha = 0;
        this.Series = 0;

        
    }

}
