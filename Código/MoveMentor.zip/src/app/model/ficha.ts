export class Ficha {
    IDFicha: number;
    IDUsuario: number;
    Nome: string;
    Descricao: string;
    DataDeCadastro: string;
    Flag: boolean;

    constructor() {
        this.IDFicha = 0;
        this.IDUsuario = 0;
        this.Nome = "";
        this.Descricao = "";
        this.DataDeCadastro = "";
        this.Flag = true;
    }
}
