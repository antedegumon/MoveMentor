import { Alerta } from './alerta';

describe('Alerta', () => {
  it('should create an instance', () => {
    expect(new Alerta()).toBeTruthy();
  });
});
