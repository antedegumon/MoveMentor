import { TreinoExtra } from './treinoextra';

describe('Treinoextra', () => {
  it('should create an instance', () => {
    expect(new TreinoExtra()).toBeTruthy();
  });
});
