export class Alerta {
    IDComentario: number;
    Comentario: string;
    IDExercicio: number;
    IDUsuario: number;


    constructor(){
        this.IDComentario = 0;
        this.Comentario = "";
        this.IDExercicio = 0;
        this.IDUsuario = 0;
        
    }
}

