import { Exercicio } from './exercicio';

describe('Exercicio', () => {
  it('should create an instance', () => {
    expect(new Exercicio()).toBeTruthy();
  });
});
