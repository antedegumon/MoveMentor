import { Fichaexercicio } from './fichaexercicio';

describe('Fichaexercicio', () => {
  it('should create an instance', () => {
    expect(new Fichaexercicio()).toBeTruthy();
  });
});
