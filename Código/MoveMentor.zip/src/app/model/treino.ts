export class Treino {
    IDTreino: number;
    IDFicha: number;
    Descricao: string;
    DataRealizada: string;
    Flag: boolean;
    

    constructor() {
        this.IDTreino = 0;
        this.IDFicha = 0;
        this.Descricao = "";
        this.DataRealizada = "";
        this.Flag = true;
    }
}
