
import { LocalTime } from "@js-joda/core";

export class Corrida {
    IDCorrida : number;
    IDUsuario : number;
    Descricao : string;
    DataRealizada !: Date;
    Distancia : number;
    Calorias : number;
    Tempo !: LocalTime;
  

    
    constructor(){
        this.IDCorrida = 0;
        this.IDUsuario = 0;
        this.Descricao = "";
        this.Distancia = 0;
        this.Calorias = 0;
    }
}

