import { Coordenadas } from './coordenadas';

describe('Coordenadas', () => {
  it('should create an instance', () => {
    expect(new Coordenadas()).toBeTruthy();
  });
});
