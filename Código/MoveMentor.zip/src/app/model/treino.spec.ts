import { Treino } from './treino';

describe('Treino', () => {
  it('should create an instance', () => {
    expect(new Treino()).toBeTruthy();
  });
});
