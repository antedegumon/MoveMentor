import { Ficha } from './ficha';

describe('Ficha', () => {
  it('should create an instance', () => {
    expect(new Ficha()).toBeTruthy();
  });
});
