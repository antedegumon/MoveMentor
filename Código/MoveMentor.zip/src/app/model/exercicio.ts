import { LocalTime } from "@js-joda/core";

export class Exercicio {
    IDExercicio : number;
    Nome : string;
    Descricao : string;
    IDCategoria : number;
    Imagem : string;
    Instrucoes : string;
    Flag : boolean;
    Series !: number;
    Repeticoes !: number;
    Tempo !: LocalTime;
    

    constructor(){
        this.IDExercicio = 0;
        this.Nome = "";
        this.Descricao = "";
        this.IDCategoria = 0;
        this.Imagem = "";
        this.Instrucoes = "";
        this.Flag = false;
    }

    
}





