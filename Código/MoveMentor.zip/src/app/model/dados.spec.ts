import { Dados } from './dados';

describe('Dados', () => {
  it('should create an instance', () => {
    expect(new Dados()).toBeTruthy();
  });
});
