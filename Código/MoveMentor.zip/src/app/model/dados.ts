export class Dados {
    IDDadosCorporais !: number;
    IDUsuario : number;
    DataRegistro : string;
    Peso : number;
    Altura : number;
    PressaoMax !: number;
    PressaoMin !: number;
    Colesterol !: number;
    Glicose !: number;
    PercentualGordura !: number;
    MedidaAbdominal !: number;

    constructor(){
        this.IDDadosCorporais = 0;
        this.IDUsuario = 0;
        this.DataRegistro = "";
        this.Peso = 0;
        this.Altura = 0;
    }
}

