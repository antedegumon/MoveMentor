import { Corrida } from './corrida';

describe('Corrida', () => {
  it('should create an instance', () => {
    expect(new Corrida()).toBeTruthy();
  });
});
