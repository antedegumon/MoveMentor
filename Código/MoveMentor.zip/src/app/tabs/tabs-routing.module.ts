import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'inicio',
        loadChildren: () => import('../pages/inicio/inicio.module').then(m => m.InicioPageModule)
      },
      {
        path: 'dados',
        loadChildren: () => import('../pages/dados/dados.module').then(m => m.DadosPageModule)
      },
      {
        path: 'cad-dados',
        loadChildren: () => import('../pages/cad-dados/cad-dados.module').then(m => m.CadDadosPageModule)
      },
      {
        path: 'cad-dados/:id',
        loadChildren: () => import('../pages/cad-dados/cad-dados.module').then(m => m.CadDadosPageModule)
      },
      {
        path: 'treinos',
        loadChildren: () => import('../pages/treinos/treinos.module').then(m => m.TreinosPageModule)
      },
      {
        path: 'corrida',
        loadChildren: () => import('../pages/corridas/corridas.module').then(m => m.CorridasPageModule)
      },
      {
        path: 'fichas',
        loadChildren: () => import('../pages/fichas/fichas.module').then(m => m.FichasPageModule)
      },
      {
        path: 'treino-add',
        loadChildren: () => import('../pages/treino-add/treino-add.module').then(m => m.TreinoAddPageModule)
      },
      {
        path: 'treino-add/:id',
        loadChildren: () => import('../pages/treino-add/treino-add.module').then(m => m.TreinoAddPageModule)
      },
      {
        path: 'ficha-add',
        loadChildren: () => import('../pages/ficha-add/ficha-add.module').then(m => m.FichaAddPageModule)
      },
      {
        path: 'ficha-add/:id',
        loadChildren: () => import('../pages/ficha-add/ficha-add.module').then(m => m.FichaAddPageModule)
      },
      {
        path: 'alerta',
        loadChildren: () => import('../pages/alerta/alerta.module').then(m => m.AlertaPageModule)
      },
      {
        path: 'alerta/:id',
        loadChildren: () => import('../pages/alerta/alerta.module').then(m => m.AlertaPageModule)
      },
      {
        path: 'corrida-start',
        loadChildren: () => import('../pages/corrida-start/corrida-start.module').then(m => m.CorridaStartPageModule)
      },
      {
        path: 'corrida-start/:id',
        loadChildren: () => import('../pages/corrida-start/corrida-start.module').then(m => m.CorridaStartPageModule)
      },
      {
        path: 'listadados',
        loadChildren: () => import('../pages/listadados/listadados.module').then(m => m.ListadadosPageModule)
      },
      {
        path: '',
        redirectTo: '/tabs/inicio',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/inicio',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
})
export class TabsPageRoutingModule {}
