import { Component, OnInit, ViewChild} from '@angular/core';
import { IonPopover } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Corrida } from 'src/app/model/corrida';
import { CorridaService } from 'src/app/services/corrida.service';
import { ActivatedRoute } from '@angular/router';
import { LocalDate } from '@js-joda/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';
import { Router } from '@angular/router';
import { LocalTime } from "@js-joda/core";
import { NavController } from '@ionic/angular';
import { CoordenadasService } from 'src/app/services/coordenadas.service';

@Component({
  selector: 'app-corridas',
  templateUrl: './corridas.page.html',
  styleUrls: ['./corridas.page.scss'],
})
export class CorridasPage implements OnInit {
  
 
  usuario: Usuario;
  isSubModalOpen = true;  // Controle do novo modal
  corridas: Corrida[] = [];
  
 

  constructor(
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private usuarioService: UsuarioService,
    private corridaService: CorridaService,
    private coordenadasService: CoordenadasService,
    private navController: NavController
  ) {
   
    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");

   
    
   }

  ngOnInit() {
   

   
  }

  async reload(){
    window.location.reload();
  }
  

  async ionViewWillEnter() {
    this.carregarLista();
  }

  async carregarLista() {
    // Carregar treinos
   

    // Carregar fichas
    await this.corridaService.listar(this.usuario.IDUsuario).then((json) => {
      this.corridas = <Corrida[]>(json);
    });
  }

  @ViewChild('popover') popover!: IonPopover;

  // Method to open popover
  openPopover(ev: Event) {
    this.popover.event = ev;
    this.popover.present();
  }

  closePopover() {
    this.popover.dismiss();
  }


  editarUsuario() {
    this.closePopover();
    this.navController.navigateForward(`/cadastro/${this.usuario.IDUsuario}`);
  }
  
  async sair(){
    this.usuarioService.encerrarAutenticacao();
    this.closePopover();
    this.navController.navigateBack('/login');
    
  }

  async desativar(corrida: Corrida){
    const alert = await this.alertController.create({
      header: 'Confirma a exclusão?',
      message: corrida.Descricao,
      buttons: [
        {
          text: 'Cancelar',
          cssClass: 'danger',
        }, {
          text: 'Confirmar',
          cssClass: 'success',

          
          handler: () => {
            this.coordenadasService.desativar(corrida.IDCorrida)
            .then(() => {
              this.carregarLista();
            }).catch(() => {
              this.exibirMensagem('Erro ao excluir o Coordenadas.');
            });

            this.corridaService.desativar(corrida.IDCorrida)
              .then(() => {
                this.carregarLista();
                this.exibirMensagem('Corrida excluída com sucesso!!!');
              }).catch(() => {
                this.exibirMensagem('Erro ao excluir o Corrida.');
              });
          }
        }
      ]
    });
    await alert.present();
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
 

}
