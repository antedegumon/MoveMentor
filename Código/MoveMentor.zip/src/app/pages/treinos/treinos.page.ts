import { Component, OnInit, ViewChild} from '@angular/core';
import { IonPopover } from '@ionic/angular';
import { Treino } from 'src/app/model/treino';
import { Ficha } from 'src/app/model/ficha';
import { TreinoService } from 'src/app/services/treino.service';
import { FichaService } from 'src/app/services/ficha.service';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Usuario } from 'src/app/model/usuario';

@Component({
  selector: 'app-treinos',
  templateUrl: './treinos.page.html',
  styleUrls: ['./treinos.page.scss'],
})
export class TreinosPage implements OnInit {
  treinos: Treino[];
  fichas: Ficha[];
  usuario: Usuario;
  

 

  constructor(private activatedRoute: ActivatedRoute, private formBuilder: FormBuilder, private fichaService: FichaService, private treinoService: TreinoService, private toastController: ToastController, private alertController: AlertController, private router : Router) { 
    this.treinos = [];
    this.fichas = [];
    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
    console.log(this.usuario);
  }

  ngOnInit() {
  }

  async ionViewWillEnter() {
    
    this.carregarLista();
  }
  

  formatDate(dateString: string): string {
    const [year, month, day] = dateString.split('-');
    return `${day}/${month}/${year}`;
  }

  async carregarLista() {
    // Carregar treinos
    await this.treinoService.listar(this.usuario.IDUsuario).then((json) => {
      this.treinos = <Treino[]>(json);
    });

    // Carregar fichas
    await this.fichaService.listar().then((json) => {
      this.fichas = <Ficha[]>(json);
    });
  }

  getNomeFicha(idFicha: number): string {
    const ficha = this.fichas.find(f => f.IDFicha === idFicha);
    return ficha ? ficha.Nome : 'Ficha não encontrada';
  }

  async desativar(treino: Treino){
    const alert = await this.alertController.create({
      header: 'Confirma a exclusão?',
      message: treino.Descricao,
      buttons: [
        {
          text: 'Cancelar',
          cssClass: 'danger',
        }, {
          text: 'Confirmar',
          cssClass: 'success',

          handler: () => {
            this.treinoService.desativar(treino.IDTreino)
              .then(() => {
                this.carregarLista();
                this.exibirMensagem('Treino excluído com sucesso!!!');
              }).catch(() => {
                this.exibirMensagem('Erro ao excluir o treino.');
              });
          }
        }
      ]
    });
    await alert.present();
  }

  async reload(){
    window.location.reload();
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }

  @ViewChild('popover') popover!: IonPopover;

  // Method to open popover
  openPopover(ev: Event) {
    this.popover.event = ev;
    this.popover.present();
    
  }


}
