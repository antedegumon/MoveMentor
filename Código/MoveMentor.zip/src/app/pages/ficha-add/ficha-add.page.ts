import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Treino } from 'src/app/model/treino';
import { TreinoService } from 'src/app/services/treino.service';
import { FichaService } from 'src/app/services/ficha.service';
import { ExercicioService } from 'src/app/services/exercicio.service';
import { Fichaexercicio } from 'src/app/model/fichaexercicio';
import { FichaexercicioService } from 'src/app/services/fichaexercicio.service';
import { Ficha } from 'src/app/model/ficha';
import { Exercicio } from 'src/app/model/exercicio';
import { ActivatedRoute } from '@angular/router';
import { LocalDate } from '@js-joda/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { Router } from '@angular/router';
import { LocalTime } from "@js-joda/core";

@Component({
  selector: 'app-add-ficha',
  templateUrl: './ficha-add.page.html',
  styleUrls: ['./ficha-add.page.scss'],
})
export class FichaAddPage implements OnInit {
  formGroup: FormGroup;
  
  fichas: Ficha[] = [];
  ficha: Ficha;
  fichaExercicios: Fichaexercicio[] = [];
  exercicios: Exercicio[] = [];
  usuario: Usuario;
  isModalOpen = false;
  isSubModalOpen = false;  // Controle do novo modal
  todosExercicios: Exercicio[] = [];
  subFormGroup: FormGroup; // Formulário para o novo modal
  tipoRepeticao: string = 'quantidade'; // Valor inicial
  selectedExercicio: Exercicio | null = null;
  repeticoesQuantidade: number | null = null; // Adicione esta linha
  tempo: string | null = null; // Adicione esta linha
  isEditMode: boolean;

  filteredExercicios: Exercicio[] = []; // Lista filtrada
  searchTerm: string = ''; // Termo de pesquisa

  constructor(
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private formBuilder: FormBuilder,
    private fichaService: FichaService,
    private exercicioService: ExercicioService,
    private activatedRoute: ActivatedRoute,
    private fichaexercicioService: FichaexercicioService,
    private treinoService: TreinoService
  ) {
    this.ficha = new Ficha();
    this.isEditMode = false;

    
    
    this.formGroup = this.formBuilder.group({
      'Nome': [this.ficha.Nome, Validators.required],
      'Descricao': [this.ficha.Descricao, Validators.required]
    });

    this.subFormGroup = this.formBuilder.group({
      'series': [0, Validators.required],
      'repeticoes': [0],
      'minutos': [0],
      'segundos': [0]
    });

    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
  }

  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  openSubModal(exercicio: Exercicio) {
    this.selectedExercicio = exercicio;
    this.isSubModalOpen = true;
  }

  closeSubModal() {
    this.isSubModalOpen = false;
    this.selectedExercicio = null;
  }

  ngOnInit() {}

  filterExercicios() {
    const term = this.searchTerm.toLowerCase();
    this.filteredExercicios = this.todosExercicios.filter(exercicio => 
      exercicio.Nome.toLowerCase().includes(term)
    );
  }
  
  ionViewWillEnter(){
    this.formGroup.reset();
    this.carregarFichas();
    this.isEditMode = false;

    let id = parseFloat(this.activatedRoute.snapshot.params['id']);
    if (!isNaN(id)) {
      this.isEditMode = true;
      this.fichaService.buscarPorId(id).then((json) => {
        this.ficha = <Ficha>(json);
        this.formGroup.get('Descricao')?.setValue(this.ficha.Descricao);
        this.formGroup.get('Nome')?.setValue(this.ficha.Nome);
        this.carregarExercicios(this.ficha.IDFicha);
      });
    }
  }

  async carregarFichas() {
    this.fichas = await this.fichaService.listarPorUsuario(this.usuario.IDUsuario);
    this.todosExercicios = await this.exercicioService.listar();
    this.filteredExercicios = this.todosExercicios;
  }

  isSelected(exercicio: Exercicio) {
    return this.exercicios.some(e => e.Nome === exercicio.Nome);
  }

  // Adiciona ou remove o exercício do vetor 'exercicios' ao selecionar/desmarcar
  toggleExercicio(exercicio: Exercicio, event: CustomEvent) {
    if (event.detail.checked) {
      this.openSubModal(exercicio);  // Abre o modal de séries e repetições
    } else {
      this.exercicios = this.exercicios.filter(e => e.Nome !== exercicio.Nome);
    }
  }

  async reload(){
    window.location.reload();
  }

  async carregarExercicios(idFicha: number) {
    this.fichaExercicios = await this.fichaexercicioService.buscarPorId(idFicha);
    this.exercicios = [];

    for (let fichaExercicio of this.fichaExercicios) {
      let exercicio = await this.exercicioService.buscarPorId(fichaExercicio.IDExercicio);
      exercicio.Series = fichaExercicio.Series;
      
      //fichaExercicio.Repeticoes !== 0 ? exercicio.Repeticoes = fichaExercicio.Repeticoes : exercicio.Tempo = fichaExercicio.Tempo;
      exercicio.Repeticoes = fichaExercicio.Repeticoes;
      exercicio.Tempo = fichaExercicio.Tempo;
      this.exercicios.push(exercicio);
    }
    
    console.log(this.exercicios);
  }

  async salvar() {
    if (this.formGroup.valid) {
      this.ficha = this.formGroup.value;
      this.ficha.DataDeCadastro = LocalDate.now().toString();
      this.ficha.Flag = true;
      this.ficha.IDFicha = parseFloat(this.activatedRoute.snapshot.params['id']) || 0;
      this.ficha.IDUsuario = this.usuario.IDUsuario;
  
      console.log(this.ficha);
  
      const alert = await this.alertController.create({
        header: 'Confirma o cadastro?',
        message: this.ficha.Nome,
        buttons: [
          {
            text: 'Cancelar',
            cssClass: 'danger',
          }, {
            text: 'Confirmar',
            cssClass: 'success',
            handler: async () => { // Tornar o handler assíncrono
              try {
                let ficha = await this.fichaService.salvar(this.ficha); // await só pode ser usado em funções async
                console.log(ficha);
                console.log(ficha.IDFicha);
                
                this.exibirMensagem('Ficha cadastrada com sucesso!!!');
                
            
                this.fichaExercicios.forEach(fichaExercicio => {
                  fichaExercicio.IDFicha = ficha.IDFicha;
                  try{
                    this.fichaexercicioService.salvar(fichaExercicio);
                  } catch(error){
                    this.exibirMensagem('Erro ao cadastrar o exercicio na ficha.');
                  }
                 
                } );
                console.log(this.fichaExercicios);
                //this.router.navigate(['/tabs/fichas']);
              } catch (error) {
                this.exibirMensagem('Erro ao cadastrar o ficha.');
              }
            }
          }
        ]
      });
  
      await alert.present();
    }
  }

  async addFicha() {
    if (this.selectedExercicio) {
      const ficha = new Fichaexercicio();
      ficha.IDExercicio = this.selectedExercicio.IDExercicio; // Certifique-se de ter um ID para o exercício
      ficha.IDFicha = 0; // Defina o ID do treino conforme necessário
      ficha.Series = this.subFormGroup.value.series;
      
      this.selectedExercicio.Series = ficha.Series = this.subFormGroup.value.series;
      let tempo: LocalTime | null = null;
      if (this.tipoRepeticao === 'tempo') {


        const minutos = this.subFormGroup.get('minutos')?.value || 0;
        console.log("minuto"+minutos);
        const segundos = this.subFormGroup.get('segundos')?.value || 0;
        console.log("segundos"+segundos);
        tempo = this.convertToLocalTime(minutos, segundos);
        ficha.Tempo = tempo;
        this.selectedExercicio.Tempo = tempo;
      }
      if (this.tipoRepeticao === 'quantidade') {
        
        ficha.Repeticoes = this.subFormGroup.value.repeticoes || 0;
      this.selectedExercicio.Repeticoes = this.subFormGroup.value.repeticoes || 0;
      }
      
      this.fichaExercicios.push(ficha);
      this.exercicios.push(this.selectedExercicio);
      this.closeSubModal();
    }
  }

  formatarTempo(tempo: LocalTime | null): string {
    if (tempo) {
      const tempoStr = tempo.toString(); // Obtém o tempo no formato hh:mm:ss
      const partes = tempoStr.split(':');
      if (partes.length === 3) { // Verifique se a divisão retornou o formato esperado
        const horas = partes[0];
        const minutos = partes[1];
        const segundos = partes[2];
        return `${this.preencherComZero(minutos)}:${this.preencherComZero(segundos)}`;
      }
    }
    return '00:00'; // Valor padrão se `tempo` for `null` ou não tiver o formato esperado
  }
  
  preencherComZero(valor: number | string): string {
    if (valor === undefined || valor === null) {
      return '00';
    }
    const num = typeof valor === 'string' ? parseInt(valor, 10) : valor;
    return num.toString().padStart(2, '0');
  }

  convertToLocalTime(minutos: number, segundos: number): LocalTime {
    minutos = minutos || 0;

    
    segundos = segundos || 0;
    return LocalTime.of(0, minutos, segundos);
  }

  

  onTipoRepeticaoChange(event: any) {
    this.tipoRepeticao = event.detail.value;
    // Limpa os campos dependendo da seleção
    if (this.tipoRepeticao === 'quantidade') {
      this.subFormGroup.get('minutos')?.setValue(0);
      this.subFormGroup.get('segundos')?.setValue(0);
    } else if (this.tipoRepeticao === 'tempo') {
      this.subFormGroup.get('repeticoes')?.setValue(null);
    }
  }

  

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}
