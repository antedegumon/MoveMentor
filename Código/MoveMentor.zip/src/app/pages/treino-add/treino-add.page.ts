import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Treino } from 'src/app/model/treino';
import { TreinoService } from 'src/app/services/treino.service';
import { TreinoExtraService } from 'src/app/services/treinoextra.service';
import { FichaService } from 'src/app/services/ficha.service';
import { ExercicioService } from 'src/app/services/exercicio.service';
import { FichaexercicioService } from 'src/app/services/fichaexercicio.service';
import { Ficha } from 'src/app/model/ficha';
import { Exercicio } from 'src/app/model/exercicio';
import { ActivatedRoute } from '@angular/router';
import { LocalDate } from '@js-joda/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { Router } from '@angular/router';
import { LocalTime } from "@js-joda/core";
import { TreinoExtra } from 'src/app/model/treinoextra';

@Component({
  selector: 'app-add-treino',
  templateUrl: './treino-add.page.html',
  styleUrls: ['./treino-add.page.scss'],
})
export class TreinoAddPage implements OnInit {
  isEditMode: boolean = false;
  formGroup: FormGroup;
  fichas: Ficha[] = [];
  treino: Treino;
  exercicios: Exercicio[] = [];
  treinoextras: TreinoExtra[] = [];
  usuario : Usuario;
  isModalOpen = false;
  isSubModalOpen = false;  // Controle do novo modal
  todosExercicios: Exercicio[] = [];
  subFormGroup: FormGroup; // Formulário para o novo modal
  tipoRepeticao: string = 'quantidade'; // Valor inicial
  selectedExercicio: Exercicio | null = null;
  repeticoesQuantidade: number | null = null; // Adicione esta linha
  tempo: string | null = null; // Adicione esta linha
  isExercicioModalOpen: boolean = false;

  filteredExercicios: Exercicio[] = []; // Lista filtrada
  searchTerm: string = ''; // Termo de pesquisa

  

  constructor( private router: Router, private toastController : ToastController, private alertController : AlertController, private formBuilder: FormBuilder, private fichaService: FichaService, private exercicioService: ExercicioService, private activatedRoute: ActivatedRoute, private fichaexercicioService: FichaexercicioService, private treinoService: TreinoService, private treinoExtraService: TreinoExtraService ) {
    this.treino = new Treino;
    
    this.formGroup = this.formBuilder.group({
      'Descricao': [this.treino.Descricao, Validators.required],
      'IDFicha': [this.treino.IDFicha, Validators.required]
    });

    this.subFormGroup = this.formBuilder.group({
      'series': [0, Validators.required],
      'repeticoes': [0],
      'minutos': [0],
      'segundos': [0]
    });
   

    

    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
  }

  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  openSubModal(exercicio: Exercicio) {
    this.selectedExercicio = exercicio;
    this.isSubModalOpen = true;
  }

  closeSubModal() {
    this.isSubModalOpen = false;
    this.selectedExercicio = null;
  }

   filterExercicios() {
    const term = this.searchTerm.toLowerCase();
    this.filteredExercicios = this.todosExercicios.filter(exercicio => 
      exercicio.Nome.toLowerCase().includes(term)
    );
  }

  ngOnInit() {}
  
  ionViewWillEnter(){
    this.formGroup.reset();
    this.carregarFichas();
    
    
    let id = parseFloat(this.activatedRoute.snapshot.params['id']);

    console.log(this.activatedRoute.snapshot.params);

    if (!isNaN(id)) {
      this.treinoService.buscarPorId(id).then((json) => {
        this.treino = <Treino>(json);
        this.formGroup.get('Descricao')?.setValue(this.treino.Descricao);
        this.formGroup.get('IDFicha')?.setValue(this.treino.IDFicha);
        this.carregarExerciciosExtra(this.treino.IDFicha, this.treino.IDTreino);
        this.isEditMode = true;
      });
    }
    else{
    }
  }

  async reload(){
    window.location.reload();
  }

  async carregarFichas() {
    this.fichas = await this.fichaService.listarPorUsuario(this.usuario.IDUsuario);
    this.todosExercicios = await this.exercicioService.listar();
    this.filteredExercicios = this.todosExercicios;
   
  }

 


  isSelected(exercicio: Exercicio) {
    return this.exercicios.some(e => e.Nome === exercicio.Nome);
  }

  isSelectedTreino(exercicio: Exercicio){

    
    
    for (let treino of this.treinoextras) {
        if(treino.IDExercicio === exercicio.IDExercicio){
          
          return treino.Situacao;
          //return false;
          
        }
    }
    if(!this.treinoextras.some(e => e.IDExercicio === exercicio.IDExercicio)){
      if(this.isEditMode){
        return true;
        //return false;
      }else{
        return false;
      }
      
    }
    return false;
  }


 async carregarExercicios(idFicha: number) {
    // Carrega os exercícios da ficha especificada
    const fichaExercicios = await this.fichaexercicioService.buscarPorId(idFicha);
    
    this.exercicios = [];
    this.treinoextras = [];

    // Adiciona os exercícios da ficha ao array de exercícios
    for (let fichaExercicio of fichaExercicios) {
      let exercicio = await this.exercicioService.buscarPorId(fichaExercicio.IDExercicio);
      exercicio.Series = fichaExercicio.Series;
      exercicio.Repeticoes = fichaExercicio.Repeticoes;
      exercicio.Tempo = fichaExercicio.Tempo;
      this.exercicios.push(exercicio);
      if(!this.isEditMode){
        this.addExTreino(exercicio, false);
      }
      

    }
/*
    this.todosExercicios = await this.exercicioService.listar();
    for (let exercicio of this.todosExercicios) {
      for (let fExercicio of fichaExercicios) {
    this.todosExercicios = this.todosExercicios.filter(ex => ex.idExercicio !== fExercicio.idExercicio);
      }
    }*/


    console.log(this.exercicios);
}

async carregarExerciciosExtra(idFicha: number, idTreino: number) {
  // Carrega os exercícios da ficha especificada
  const fichaExercicios = await this.fichaexercicioService.buscarPorId(idFicha);
  
  this.exercicios = [];
  this.treinoextras = [];

  // Adiciona os exercícios da ficha ao array de exercícios
  for (let fichaExercicio of fichaExercicios) {
    let exercicio = await this.exercicioService.buscarPorId(fichaExercicio.IDExercicio);
    exercicio.Series = fichaExercicio.Series;
    exercicio.Repeticoes = fichaExercicio.Repeticoes;
    exercicio.Tempo = fichaExercicio.Tempo;
    console.log(exercicio);
    this.exercicios.push(exercicio);
  }

  // Carrega os exercícios extras do treino
  const treinoextras = await this.treinoExtraService.buscarPorId(idTreino);

  for (let treinoextra of treinoextras) {
    if (treinoextra.Situacao) { 
      // Caso o exercício extra esteja ativo, adiciona-o aos exercícios
      let exercicio = await this.exercicioService.buscarPorId(treinoextra.IDExercicio);
      exercicio.Series = treinoextra.Series;
      treinoextra.Repeticoes !== 0 ? exercicio.Repeticoes = treinoextra.Repeticoes : exercicio.Tempo = treinoextra.Tempo;
      this.exercicios.push(exercicio);
    } else {
      // Caso o exercício extra esteja desativado, remove-o da lista de exercícios
      this.exercicios = this.exercicios.filter(ex => ex.IDExercicio !== treinoextra.IDExercicio);
    }
  }

  console.log(this.exercicios);
}


  toggleExercicio(exercicio: Exercicio, event: CustomEvent) {
    if (event.detail.checked) {
      this.openSubModal(exercicio);  // Abre o modal de séries e repetições
    } else {
      this.exercicios = this.exercicios.filter(e => e.Nome !== exercicio.Nome);
    }
  }

  
  
  openExercicioModal(exercicio: Exercicio) {
    this.selectedExercicio = exercicio;
    this.isExercicioModalOpen = true;
  }
  
  closeExercicioModal() {
    this.isExercicioModalOpen = false;
    this.selectedExercicio = null;
  }

  async closeExercicioModalAlerta(id : number){
    console.log(id)
    this.isExercicioModalOpen = false;
    this.selectedExercicio = null;
    
    await new Promise(f => setTimeout(f, 1000));
    
    this.router.navigate(['/tabs/alerta/', id]);
  }



  


  async salvar() {
    if (this.formGroup.valid) {
      this.treino = this.formGroup.value;
      this.treino.DataRealizada = LocalDate.now().toString();
      this.treino.Flag = true;
      this.treino.IDTreino = parseFloat(this.activatedRoute.snapshot.params['id']) || 0;

      
      

      const alert = await this.alertController.create({
        header: 'Confirma o cadastro?',
        message: this.treino.Descricao,
        buttons: [
          {
            text: 'Cancelar',
            cssClass: 'danger',
          }, {
            text: 'Confirmar',
            cssClass: 'success',
  
            handler: async () => {
              try {
                // Aguarda o retorno da promessa
                const treinoSalvo = await this.treinoService.salvar(this.treino);
                
                // Supondo que treinoSalvo seja o objeto retornado pela promessa
                const treinoNow = <Treino>treinoSalvo;
                this.treino = treinoNow;
                
                this.exibirMensagem('Treino cadastrado com sucesso!!!');
             
                // Atualiza o idTreino de todos os itens de treinoextra
                console.log(treinoNow);
                this.treinoextras.forEach(item => {
                  item.IDTreino = treinoNow.IDTreino;
                });

                const fichaExercicios = await this.fichaexercicioService.buscarPorId(treinoNow.IDFicha);

                const treinoExtrasFiltrados = this.treinoextras.filter(item => {
    
                const exercicioNaFicha = fichaExercicios.some(ficha => ficha.IDExercicio === item.IDExercicio);

    
                if (!exercicioNaFicha && item.Situacao === true) {
                  return true; // Mantém o item
                }

                // Se o exercício está na ficha e marcado como "não feito" (situacao === false)
                if (exercicioNaFicha && item.Situacao === false) {
                  return true; // Mantém o item
                }

                // Caso contrário, filtra o item
                return false;
              });
          console.log('TF');
          console.log(treinoExtrasFiltrados);

          for (const item of treinoExtrasFiltrados) {
            try {
              await this.treinoExtraService.salvar(item);
              console.log('Treino extra salvo com sucesso!');
            } catch (error) {
              console.error('Erro ao salvar treino extra', error);
            }
          }

          this.router.navigate(['/tabs/treinos']);
        } catch (error) {
          // Em caso de erro
          this.exibirMensagem('Erro ao cadastrar o treino.');
        }
            }
            
          }
          
        ]
      });

      await alert.present();
    }
  }

  async addTreino() {
    if (this.selectedExercicio) {
      const treino = new TreinoExtra();
      treino.IDExercicio = this.selectedExercicio.IDExercicio; // Certifique-se de ter um ID para o exercício
      treino.IDTreino = 0; // Defina o ID do treino conforme necessário
      treino.Series = this.subFormGroup.value.series;
      
      this.selectedExercicio.Series = treino.Series = this.subFormGroup.value.series;
      let tempo: LocalTime | null = null;
      if (this.tipoRepeticao === 'tempo') {


        const minutos = this.subFormGroup.get('minutos')?.value || 0;
        console.log("minuto"+minutos);
        const segundos = this.subFormGroup.get('segundos')?.value || 0;
        console.log("segundos"+segundos);
        tempo = this.convertToLocalTime(minutos, segundos);
        treino.Tempo = tempo;
        this.selectedExercicio.Tempo = tempo;
      }
      if (this.tipoRepeticao === 'quantidade') {
        
        treino.Repeticoes = this.subFormGroup.value.repeticoes || 0;
      this.selectedExercicio.Repeticoes = this.subFormGroup.value.repeticoes || 0;
      }
      
      this.treinoextras.push(treino);
      this.exercicios.push(this.selectedExercicio);
      this.closeSubModal();
    }
  }

  formatarTempo(tempo: LocalTime | null): string {
    if (tempo) {
      const tempoStr = tempo.toString(); // Obtém o tempo no formato hh:mm:ss
      const partes = tempoStr.split(':');
      if (partes.length === 3) { // Verifique se a divisão retornou o formato esperado
        const horas = partes[0];
        const minutos = partes[1];
        const segundos = partes[2];
        return `${this.preencherComZero(minutos)}:${this.preencherComZero(segundos)}`;
      }
    }
    return '00:00'; // Valor padrão se `tempo` for `null` ou não tiver o formato esperado
  }
  
  preencherComZero(valor: number | string): string {
    if (valor === undefined || valor === null) {
      return '00';
    }
    const num = typeof valor === 'string' ? parseInt(valor, 10) : valor;
    return num.toString().padStart(2, '0');
  }

  convertToLocalTime(minutos: number, segundos: number): LocalTime {
    minutos = minutos || 0;

    
    segundos = segundos || 0;
    return LocalTime.of(0, minutos, segundos);
  }

  

  onTipoRepeticaoChange(event: any) {
    this.tipoRepeticao = event.detail.value;
    // Limpa os campos dependendo da seleção
    if (this.tipoRepeticao === 'quantidade') {
      this.subFormGroup.get('minutos')?.setValue(0);
      this.subFormGroup.get('segundos')?.setValue(0);
    } else if (this.tipoRepeticao === 'tempo') {
      this.subFormGroup.get('repeticoes')?.setValue(null);
    }
  }

  async marcarComoFeito(exercicio: Exercicio, event: CustomEvent) {
    let existe = false;
    
    // Verificar se o exercício já existe em treinoextras
    for (let treino of this.treinoextras) {
      if (treino.IDExercicio === exercicio.IDExercicio) {
        treino.Situacao = event.detail.checked; // Marcar/desmarcar com base no evento
        existe = true;
        break;
      }
    }
  
    // Se o exercício ainda não existir e for marcado, adicioná-lo
    if (!existe) {
      this.addExTreino(exercicio, event.detail.checked);
    }
    
    console.log(this.treinoextras);
  }
  
  async addExTreino(exercicio: Exercicio, situacao: boolean){
    const novoTreinoExtra = new TreinoExtra();
    novoTreinoExtra.IDExercicio = exercicio.IDExercicio;
    novoTreinoExtra.IDTreino = 0; // Defina o ID conforme necessário
    novoTreinoExtra.Series = exercicio.Series;
    novoTreinoExtra.Repeticoes = exercicio.Repeticoes;
    novoTreinoExtra.Tempo = exercicio.Tempo;
    novoTreinoExtra.Situacao = situacao; // Marca como feito
    this.treinoextras.push(novoTreinoExtra);
  }

  
  async buscarExercicio(id:number){
    for (let exercicio of this.exercicios) {
      if(exercicio.IDExercicio === id){
        return exercicio;
      }
      
    }
    return null;
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }

}
