import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TreinoAddPageRoutingModule } from './treino-add-routing.module';

import { TreinoAddPage } from './treino-add.page';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TreinoAddPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [TreinoAddPage]
})
export class TreinoAddPageModule {}
