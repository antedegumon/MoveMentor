import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TreinoAddPage } from './treino-add.page';

const routes: Routes = [
  {
    path: '',
    component: TreinoAddPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TreinoAddPageRoutingModule {}
