import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TreinoAddPage } from './treino-add.page';

describe('TreinoAddPage', () => {
  let component: TreinoAddPage;
  let fixture: ComponentFixture<TreinoAddPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(TreinoAddPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
