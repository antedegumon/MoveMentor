import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CorridaStartPage } from './corrida-start.page';

describe('CorridaStartPage', () => {
  let component: CorridaStartPage;
  let fixture: ComponentFixture<CorridaStartPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CorridaStartPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
