import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CorridaStartPageRoutingModule } from './corrida-start-routing.module';

import { CorridaStartPage } from './corrida-start.page';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CorridaStartPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [CorridaStartPage]
})
export class CorridaStartPageModule {}
