import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CorridaStartPage } from './corrida-start.page';

const routes: Routes = [
  {
    path: '',
    component: CorridaStartPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CorridaStartPageRoutingModule {}
