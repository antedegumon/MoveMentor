import { Component, OnInit, ViewChild} from '@angular/core';
import { IonPopover } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { LocalDate } from '@js-joda/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { Corrida } from 'src/app/model/corrida';
import { CorridaService } from 'src/app/services/corrida.service';
import { LocalTime } from '@js-joda/core';
import { Coordenadas } from 'src/app/model/coordenadas';
import { CoordenadasService } from 'src/app/services/coordenadas.service';


@Component({
  selector: 'app-corrida-start',
  templateUrl: './corrida-start.page.html',
  styleUrls: ['./corrida-start.page.scss'],
})
export class CorridaStartPage implements OnInit {
  formGroup: FormGroup;
  corrida: Corrida;
  coordenadasCorrida: Coordenadas[] = [];
  coordenadasCorridaAntes: Coordenadas[] = [];
  usuario: Usuario;
  isSubModalOpen = true;  // Controle do novo modal
  localizar: boolean = false;
  coordenada!: Coordenadas;
  botao: string = 'Iniciar';
  save: boolean = false;
  


 private coordenadas: Coordenadas[] = [];
  private intervalId: any;
  private ordemAtual: number = 1;
  startTime: LocalTime; 
  elapsedTime: LocalTime; 
  timerId: any;
  id: number = 0;
  isEditMode: boolean = false;
 
  
 

  constructor(
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private usuarioService: UsuarioService,
    private navController: NavController,
    private corridaService: CorridaService,
    private coordenadasService: CoordenadasService,

    

  ) {
    
    this.corrida = new Corrida;
    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
    this.startTime = LocalTime.now(); 
    this.elapsedTime = LocalTime.of(0, 0, 0);
    
    this.formGroup = this.formBuilder.group({
      'Descricao': [this.corrida.Descricao, Validators.required],
      'Distancia': [this.corrida.Distancia],
      'Tempo': [this.corrida.Tempo]
      
    });
    
   }

  ngOnInit() {}
  
  ionViewWillEnter(){
    this.formGroup.reset();
    
    
    this.id = parseFloat(this.activatedRoute.snapshot.params['id']);

    if (!isNaN(this.id)) {
      console.log('mode de edição');
    
      this.isEditMode = true;
      this.botao = 'Voltar';
      this.coordenadasService.listar(this.id).then((json) => {
        
        this.coordenadasCorridaAntes = <Coordenadas []>(json);
         //console.log(this.coordenadasCorrida);
         const distancia = this.calcularDistanciaTotal(this.coordenadasCorridaAntes);
        
        this.formGroup.get('Distancia')?.setValue(distancia);
         this.desenharPercurso();
          
         
       
      });

      
      

      this.corridaService.buscarPorId(this.id).then((json) => {
        
        this.corrida = <Corrida>(json);
        this.formGroup.get('Descricao')?.setValue(this.corrida.Descricao);
        //this.formGroup.get('Distancia')?.setValue(this.corrida.Distancia);
        
        this.formGroup.get('Tempo')?.setValue(this.corrida.Tempo);
        console.log(this.corrida);
      
       
       
      });

     
    }
    else{
      this.formGroup.reset();
      this.isEditMode = false;
      this.id = 0;
    }
    console.log(this.id);
    
  }

  

  async reload(){
    window.location.reload();
  }

  



  @ViewChild('popover') popover!: IonPopover;

  // Method to open popover
  openPopover(ev: Event) {
    this.popover.event = ev;
    this.popover.present();
  }

  closePopover() {
    this.popover.dismiss();
  }


  editarUsuario() {
    this.closePopover();
    this.navController.navigateForward(`/cadastro/${this.usuario.IDUsuario}`);
  }
  
  async sair(){
    this.usuarioService.encerrarAutenticacao();
    this.closePopover();
    this.navController.navigateBack('/login');
    
  }

  desenharPercurso() {
    const canvas: HTMLCanvasElement = document.getElementById('mapCanvas') as HTMLCanvasElement;
    this.coordenadasCorrida = this.transformarCoordenadas(this.coordenadasCorridaAntes);
    //console.log(this.coordenadasCorrida);
    if (canvas) {
      const ctx = canvas.getContext('2d');

      if (ctx) {
        // Configurações do desenho
        ctx.strokeStyle = '#00FF00'; // Cor da linha
        ctx.lineWidth = 2;          // Largura da linha
        ctx.beginPath();

        // Movendo para o primeiro ponto
        ctx.moveTo(this.coordenadasCorrida[0].Latitude, this.coordenadasCorrida[0].Longitude);

        // Conectando os pontos na ordem
        this.coordenadasCorrida.forEach((coord) => {
          ctx.lineTo(coord.Latitude, coord.Longitude);
        });

        // Desenhar o percurso
        ctx.stroke();

        // Desenhar os pontos
        ctx.fillStyle = '#00000000';
        this.coordenadasCorrida.forEach((coord) => {
          ctx.beginPath();
          ctx.arc(coord.Latitude, coord.Longitude, 5, 0, Math.PI * 2); // Desenha um círculo em cada ponto
          ctx.fill();
        });
      } else {
        console.error('Erro ao obter o contexto 2D do canvas.');
      }
    } else {
      console.error('Canvas não encontrado.');
    }
  }

  iniciar() { 
    
    if (this.localizar){
      if(this.save){
        this.salvar();
      }else{
        this.save = true;
        this.botao = 'Salvar';
        this.coordenadas = this.filtrarEReorganizarCoordenadas(this.coordenadas);
        console.log('aaaa');
        console.log(this.coordenadas);
        const distancia = this.calcularDistanciaTotal(this.coordenadas);
        this.formGroup.get('Distancia')?.setValue(distancia);
        this.formGroup.get('Tempo')?.setValue(this.elapsedTime);
        
        this.pararRastreamento();
  
        this.desenharPercurso();
       
        
      }
    }else{
      this.botao = 'Parar Corrida';
      console.log('Iniciando...'); 
      this.localizar =true;
      this.iniciarRastreamento();
      
    }
    
  }



  iniciarRastreamento() {
    this.start();
    this.intervalId = setInterval(() => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coordenada = new Coordenadas(
            this.corrida.IDCorrida,
            position.coords.latitude,
            position.coords.longitude,
            this.ordemAtual
          );
  
          this.coordenadas.push(coordenada);
          this.ordemAtual++;
  
          console.log("Nova coordenada adicionada:", coordenada);
        },
        (error) => {
          console.error("Erro ao obter posição:", error.message);
        },
        {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0,
        }
      );
    }, 5000); // Obter posição a cada 1 segundo
  }
  
  pararRastreamento() {
    this.stop();
    if (this.intervalId !== undefined) {
      clearInterval(this.intervalId);
      console.log("Rastreamento parado.");
    }
  }
  
  



/*
  transformarCoordenadas(coordenadas: Coordenadas[]): Coordenadas[] { 
    const minLat = Math.min(...coordenadas.map(c => c.Latitude)); 
    const maxLat = Math.max(...coordenadas.map(c => c.Latitude)); 
    const minLon = Math.min(...coordenadas.map(c => c.Longitude)); 
    const maxLon = Math.max(...coordenadas.map(c => c.Longitude)); 
    const escala = 280; 
    return coordenadas.map(c => {
         const novaLatitude = ((c.Latitude - minLat) / (maxLat - minLat)) * escala + 10; 
         const novaLongitude = ((c.Longitude - minLon) / (maxLon - minLon)) * escala + 10; 
         return new Coordenadas(c.IDCorrida, novaLatitude, novaLongitude, c.Ordem); 
        }); 
    }
*/
transformarCoordenadas(coordenadas: Coordenadas[]): Coordenadas[] { 
  if (coordenadas.length === 0) return [];

  const minLat = Math.min(...coordenadas.map(c => c.Latitude)); 
  const maxLat = Math.max(...coordenadas.map(c => c.Latitude)); 
  const minLon = Math.min(...coordenadas.map(c => c.Longitude)); 
  const maxLon = Math.max(...coordenadas.map(c => c.Longitude)); 

  const larguraCanvas = 300;
  const alturaCanvas = 300;
  
  // Cálculo da escala proporcional, ajustando longitude com cosseno da latitude
  const latScale = alturaCanvas / (maxLat - minLat);
  const lonScale = larguraCanvas / ((maxLon - minLon) * Math.cos(minLat * Math.PI / 180)); 
  const escala = Math.min(latScale, lonScale) * 0.9; // Usa 90% para margem de segurança

  // Ponto médio para centralização
  const centroLat = (maxLat + minLat) / 2;
  const centroLon = (maxLon + minLon) / 2;

  return coordenadas.map(c => {
      // Centraliza os pontos em relação ao canvas
      const novaLatitude = ((c.Latitude - centroLat) * escala) + larguraCanvas / 2; 
      const novaLongitude = ((c.Longitude - centroLon) * escala) + alturaCanvas / 2; 
      
      return new Coordenadas(c.IDCorrida, novaLatitude, novaLongitude, c.Ordem); 
  }); 
}


    start() { 
      this.startTime = LocalTime.now(); 
      this.timerId = setInterval(() => { 
        const now = LocalTime.now(); 
        const duration = now.toSecondOfDay() - this.startTime.toSecondOfDay(); 
        this.elapsedTime = LocalTime.ofSecondOfDay(duration); 
        this.formGroup.get('Tempo')?.setValue(this.elapsedTime);

       }, 1000); }
        
        stop() { 
          clearInterval(this.timerId);
          console.log("Tempo total decorrido:", this.elapsedTime.toString()); 
        }

        filtrarEReorganizarCoordenadas(coordenadas: Coordenadas[]): Coordenadas[] { 
          if (coordenadas.length === 0) return []; 
          const coordenadasFiltradas: Coordenadas[] = [coordenadas[0]]; 
          for (let i = 1; i < coordenadas.length; i++) { 
            const anterior = coordenadas[i - 1]; 
            const atual = coordenadas[i]; 
            if (anterior.Latitude !== atual.Latitude || anterior.Longitude !== atual.Longitude) {
               coordenadasFiltradas.push(atual); } } // Reorganizar a ordem das coordenadas 
               for (let i = 0; i < coordenadasFiltradas.length; i++) { 
                coordenadasFiltradas[i].Ordem = i + 1; 
              } 
              
              return coordenadasFiltradas; 
            }




            calcularDistancia(lat1: number, lon1: number, lat2: number, lon2: number): number {
              const R = 6371; // Raio médio da Terra em quilômetros
            
              // Converter graus para radianos
              const radLat1 = this.toRadians(lat1);
              const radLat2 = this.toRadians(lat2);
              const deltaLat = this.toRadians(lat2 - lat1);
              const deltaLon = this.toRadians(lon2 - lon1);
            
              // Fórmula de Haversine
              const a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
                        Math.cos(radLat1) * Math.cos(radLat2) *
                        Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);
              
              const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
              const result = R * c;
            
              console.log(`Distância entre (${lat1}, ${lon1}) e (${lat2}, ${lon2}): ${result.toFixed(3)} km`);
              return result; // Distância em quilômetros
            }
            
            // Função auxiliar para converter graus em radianos
            toRadians(graus: number): number {
              return graus * (Math.PI / 180);
            }
            
            calcularDistanciaTotal(coordenadas: Coordenadas[]): number { 
              let distanciaTotal = 0;
            console.log('chego aq');
              for (let i = 1; i < coordenadas.length; i++) { 
                const coord1 = coordenadas[i - 1]; 
                const coord2 = coordenadas[i];
                console.log('chego aq');
                const distancia = this.calcularDistancia(coord1.Latitude, coord1.Longitude, coord2.Latitude, coord2.Longitude);
                
                // Ignorar distâncias muito pequenas (exemplo: erro de GPS)
                if (distancia > 0.005) { // 5 metros
                  distanciaTotal += distancia;
                }
              }
            
              const resultado = distanciaTotal.toFixed(3);
              console.log(`Distância total percorrida: ${resultado} km`);
            
              // Atualizar o formulário com a distância total
              this.formGroup.get('Distancia')?.setValue(parseFloat(resultado));
            
              return parseFloat(resultado);
            }
            


      async voltar(){
        this.navController.navigateBack('/tabs/corrida');
    }
              
    async salvar() {
      if (this.formGroup.valid) {
        this.corrida = this.formGroup.value;
        this.corrida.IDCorrida = this.id;
        this.corrida.Calorias = 123;
        console.log(this.corrida);
        const agora = new Date();
        this.corrida.DataRealizada = agora;
        this.corrida.IDUsuario = this.usuario.IDUsuario;
              
        const alert = await this.alertController.create({
          header: 'Confirma o cadastro?',
          message: this.corrida.Descricao,
          buttons: [
            {
              text: 'Cancelar',
              cssClass: 'danger',
            }, {
              text: 'Confirmar',
              cssClass: 'success',
              handler: async () => { // Tornar o handler assíncrono
                try {
                  let corrida = await this.corridaService.salvar(this.corrida); // await só pode ser usado em funções async
                  this.exibirMensagem('Corrida cadastrada com sucesso!!!');
              
                  this.coordenadas.forEach(coordenada => {
                    coordenada.IDCorrida = corrida.IDCorrida;
                    console.log('id'+corrida.IDCorrida);
                    try{
                      this.coordenadasService.salvar(coordenada);
                    } catch(error){
                      this.exibirMensagem('Erro ao cadastrar coordenadas da corrida.');
                    }
                    
                  } );
                  console.log(this.coordenadas);
                  this.router.navigate(['/tabs/corridas']);
                } catch (error) {
                  this.exibirMensagem('Erro ao cadastrar corrida.');
                }
              }
            }
          ]
        });
    
        await alert.present();
      }
    }

    async exibirMensagem(texto: string) {
      const toast = await this.toastController.create({
        message: texto,
        duration: 1500
      });
      toast.present();
    }

}

 


