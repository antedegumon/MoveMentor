import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false, 
})
export class LoginPage implements OnInit {

  usuario: Usuario;
  formGroup: FormGroup;

  constructor(
    private router: Router,
      private formBuilder: FormBuilder, 
      private usuarioService: UsuarioService, 
      private toastController: ToastController, 
      private navController: NavController
    ) {

    this.usuario = new Usuario();
    this.formGroup = this.formBuilder.group({
      'login': [this.usuario.Email, Validators.compose([Validators.required])],
      'senha': [this.usuario.Senha, Validators.compose([Validators.required])],
    })
  }

  ngOnInit() {
    this.usuarioService.encerrarAutenticacao();
  }

  autenticar() {
    let login = this.formGroup.value.login;
    let senha = this.formGroup.value.senha;

    this.usuarioService.autenticar(login, senha)
      .then((json) => {
        this.usuario = <Usuario>(json);
        console.log(this.usuario);
        console.log(this.usuario.IDUsuario);
        if (this.usuario.IDUsuario > 0) {
          this.usuarioService.registrarAutenticacao(this.usuario);
          this.router.navigate(['/tabs/inicio']);

        } else {
          this.exibirMensagem('Usuário e/ou senha inválidos!!!')

        }
      })
      .catch((erro => {
        console.error('Erro na autenticação:', erro); // Log para depuração6
        this.exibirMensagem('Erro ao autenticar! Detalhes: ' + (erro?.message || erro));
      }));
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present()
  }

}
