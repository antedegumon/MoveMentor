import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CadDadosPageRoutingModule } from './cad-dados-routing.module';

import { CadDadosPage } from './cad-dados.page';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CadDadosPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [CadDadosPage]
})
export class CadDadosPageModule {}
