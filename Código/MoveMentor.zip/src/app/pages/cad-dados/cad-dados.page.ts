import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Dados } from 'src/app/model/dados';
import { DadosService } from 'src/app/services/dados.service';
import { FichaService } from 'src/app/services/ficha.service';
import { ExercicioService } from 'src/app/services/exercicio.service';
import { Fichaexercicio } from 'src/app/model/fichaexercicio';
import { FichaexercicioService } from 'src/app/services/fichaexercicio.service';
import { Ficha } from 'src/app/model/ficha';
import { Exercicio } from 'src/app/model/exercicio';
import { ActivatedRoute } from '@angular/router';
import { LocalDate } from '@js-joda/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { Router } from '@angular/router';
import { LocalTime } from "@js-joda/core";

@Component({
  selector: 'app-dados-cad',
  templateUrl: './cad-dados.page.html',
  styleUrls: ['./cad-dados.page.scss'],
})
export class CadDadosPage implements OnInit {
  formGroup: FormGroup;
  
  dados: Dados;
  usuario: Usuario;
  isEditMode: boolean = false;
  botao: String = 'Salvar';
 
 

  constructor(
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private formBuilder: FormBuilder,
    private fichaService: FichaService,
    private exercicioService: ExercicioService,
    private activatedRoute: ActivatedRoute,
    private fichaexercicioService: FichaexercicioService,
    private dadosService: DadosService
  ) {
    this.dados = new Dados;
    this.formGroup = this.formBuilder.group({
      'Peso': [this.dados.Peso, Validators.required],
      'Altura': [this.dados.Altura, Validators.required],
      'Colesterol': [this.dados.Colesterol],
      'Glicose': [this.dados.Glicose],
      'Percentual': [this.dados.PercentualGordura],
      'Medida': [this.dados.MedidaAbdominal],
      'PressaoMax': [this.dados.PressaoMax],
      'PressaoMin': [this.dados.PressaoMin],

    });

   
    
    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
    
  }

  ngOnInit() {}

  ionViewWillEnter(){
    this.formGroup.reset();
    
    let id = parseFloat(this.activatedRoute.snapshot.params['id']);

    console.log(this.activatedRoute.snapshot.params);

    if (!isNaN(id)) {
      this.dadosService.buscarPorId(id).then((json) => {
        this.dados = <Dados>(json);
        this.formGroup.get('Peso')?.setValue(this.dados.Peso);
        this.formGroup.get('Altura')?.setValue(this.dados.Altura);
        this.formGroup.get('PressaoMax')?.setValue(this.dados.PressaoMax);
        this.formGroup.get('PressaoMin')?.setValue(this.dados.PressaoMin);
        this.formGroup.get('Colesterol')?.setValue(this.dados.Colesterol);
        this.formGroup.get('Glicose')?.setValue(this.dados.Altura);
        this.formGroup.get('PercentualGordura')?.setValue(this.dados.PercentualGordura);
        this.formGroup.get('MedidaAbdominal')?.setValue(this.dados.MedidaAbdominal);
        this.isEditMode = true;
        this.botao = 'Voltar';
      });
    }
    else{
    }
  }

  async excluir(){
    this.exibirMensagem("Excluir dados?");
  }
 

 

  async salvar() {
    if (this.formGroup.valid) {
      this.dados = this.formGroup.value;
      this.dados.IDDadosCorporais = 0;
      this.dados.DataRegistro = LocalDate.now().toString();
      
      this.dados.IDUsuario = this.usuario.IDUsuario;
  
      console.log(this.dados);
  
      const alert = await this.alertController.create({
        header: 'Confirma o cadastro?',
        buttons: [
          {
            text: 'Cancelar',
            cssClass: 'danger',
          }, {
            text: 'Confirmar',
            cssClass: 'success',
            handler: async () => { // Tornar o handler assíncrono
              try {
                let dado = await this.dadosService.salvar(this.dados); // await só pode ser usado em funções async
                this.exibirMensagem('Dados cadastrada com sucesso!!!');
                this.router.navigate(['/tabs/dados']);
            
                
              } catch (error) {
                this.exibirMensagem('Erro ao cadastrar os dados.');
              }
            }
          }
        ]
      });
  
      await alert.present();
    }
  }

  async reload(){
    window.location.reload();
  }

  async voltar(){
    this.router.navigate(['/tabs/listadados']);
  }
  

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}
