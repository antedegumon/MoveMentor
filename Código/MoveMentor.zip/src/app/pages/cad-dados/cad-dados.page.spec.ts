import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CadDadosPage } from './cad-dados.page';

describe('CadDadosPage', () => {
  let component: CadDadosPage;
  let fixture: ComponentFixture<CadDadosPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CadDadosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
