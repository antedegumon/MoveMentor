import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exercicio-info',
  templateUrl: './exercicio-info.page.html',
  styleUrls: ['./exercicio-info.page.scss'],
})
export class ExercicioInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
