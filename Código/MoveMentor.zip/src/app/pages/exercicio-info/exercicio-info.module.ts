import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ExercicioInfoPageRoutingModule } from './exercicio-info-routing.module';

import { ExercicioInfoPage } from './exercicio-info.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ExercicioInfoPageRoutingModule
  ],
  declarations: [ExercicioInfoPage]
})
export class ExercicioInfoPageModule {}
