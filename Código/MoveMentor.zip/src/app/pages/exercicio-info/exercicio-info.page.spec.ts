import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ExercicioInfoPage } from './exercicio-info.page';

describe('ExercicioInfoPage', () => {
  let component: ExercicioInfoPage;
  let fixture: ComponentFixture<ExercicioInfoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ExercicioInfoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
