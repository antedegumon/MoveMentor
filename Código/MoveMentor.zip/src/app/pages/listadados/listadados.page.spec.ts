import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ListadadosPage } from './listadados.page';

describe('ListadadosPage', () => {
  let component: ListadadosPage;
  let fixture: ComponentFixture<ListadadosPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadadosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
