import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ListadadosPageRoutingModule } from './listadados-routing.module';

import { ListadadosPage } from './listadados.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ListadadosPageRoutingModule
  ],
  declarations: [ListadadosPage]
})
export class ListadadosPageModule {}
