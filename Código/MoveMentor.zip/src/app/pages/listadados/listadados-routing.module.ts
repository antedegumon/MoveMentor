import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListadadosPage } from './listadados.page';

const routes: Routes = [
  {
    path: '',
    component: ListadadosPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ListadadosPageRoutingModule {}
