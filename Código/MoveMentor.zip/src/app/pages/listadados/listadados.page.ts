import { Component, OnInit, ViewChild } from '@angular/core';
import { IonPopover } from '@ionic/angular';
import { Dados } from 'src/app/model/dados';
import { DadosService } from 'src/app/services/dados.service';
import { ToastController, AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Usuario } from 'src/app/model/usuario';

@Component({
  selector: 'app-listadados',
  templateUrl: './listadados.page.html',
  styleUrls: ['./listadados.page.scss'],
})
export class ListadadosPage implements OnInit {
  
  dadosCorporais: Dados[] = [];
  usuario: Usuario;

  constructor(
    private dadosService: DadosService,
    private toastController: ToastController,
    private alertController: AlertController,
    private router: Router
  ) {
    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
  }

  async reload(){
    window.location.reload();
  }

  ngOnInit() {}

  async ionViewWillEnter() {
    this.carregarLista();
  }

  async carregarLista() {
    console.log('Usuário ID:', this.usuario.IDUsuario);
    await this.dadosService.listar(this.usuario.IDUsuario).then((json) => {
      this.dadosCorporais = <Dados[]>json;
    });
  }

  async desativar(dado: Dados) {
    const alert = await this.alertController.create({
      header: 'Confirma a exclusão?',
      message: `Peso: ${dado.Peso} kg - Altura: ${dado.Altura} m`,
      buttons: [
        {
          text: 'Cancelar',
          cssClass: 'danger',
        }, 
        {
          text: 'Confirmar',
          cssClass: 'success',
          handler: () => {
            this.dadosService.desativar(dado.IDDadosCorporais)
              .then(() => {
                this.carregarLista();
                this.exibirMensagem('Dado corporal excluído com sucesso!');
              })
              .catch(() => {
                this.exibirMensagem('Erro ao excluir o dado corporal.');
              });
          }
        }
      ]
    });
    await alert.present();
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }

  @ViewChild('popover') popover!: IonPopover;

  openPopover(ev: Event) {
    this.popover.event = ev;
    this.popover.present();
  }
}
