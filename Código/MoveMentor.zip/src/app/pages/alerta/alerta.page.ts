import { Component, OnInit, ViewChild} from '@angular/core';
import { Alerta } from 'src/app/model/alerta'; 
import { IonPopover } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ExercicioService } from 'src/app/services/exercicio.service';
import { ActivatedRoute } from '@angular/router';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { AlertaService } from 'src/app/services/alerta.service';

@Component({
  selector: 'app-alerta',
  templateUrl: './alerta.page.html',
  styleUrls: ['./alerta.page.scss'],
})
export class AlertaPage implements OnInit {
  usuario: Usuario;
  formGroup: FormGroup;
  alerta: Alerta;
  
 
  constructor(
    private router: Router,
    private toastController: ToastController,
    private formBuilder: FormBuilder,
    private exercicioService: ExercicioService,
    private activatedRoute: ActivatedRoute,
    private usuarioService: UsuarioService,
    private navController: NavController,
    private alertaService: AlertaService
  ) {
   
    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
    this.alerta = new Alerta;
    this.formGroup = this.formBuilder.group({
      'comentario': [this.alerta.Comentario, Validators.required]
      
    });

   }

  ngOnInit() {


   
  }

  @ViewChild('popover') popover!: IonPopover;

  // Method to open popover
  openPopover(ev: Event) {
    this.popover.event = ev;
    this.popover.present();
  }

  closePopover() {
    this.popover.dismiss();
  }


  editarUsuario() {
    this.closePopover();
    this.navController.navigateForward(`/cadastro/${this.usuario.IDUsuario}`);
  }

  async salvar(){
    this.alerta.Comentario = this.formGroup.value.comentario;
    this.alerta.IDUsuario = this.usuario.IDUsuario;
    this.alerta.IDExercicio = parseFloat(this.activatedRoute.snapshot.params['id']);
    try {
      await this.alertaService.salvar(this.alerta);
      this.exibirMensagem('Aviso enviado com sucesso!');
      
      this.navController.navigateBack('/tabs/inicio');

    } catch (error) {
      console.error('Erro ao salvar treino extra', error);
    }

  }
  

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
  
async voltar(){
  this.navController.navigateBack('/tabs/inicio');
}

  async sair(){
    this.usuarioService.encerrarAutenticacao();
    this.closePopover();
    this.navController.navigateBack('/login');
    
  }


 

}
