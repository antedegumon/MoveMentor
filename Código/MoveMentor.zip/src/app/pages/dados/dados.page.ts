import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

import { IonPopover } from '@ionic/angular';
import { Chart, registerables } from 'chart.js';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Dados } from 'src/app/model/dados';
import { DadosService } from 'src/app/services/dados.service';
import { ActivatedRoute } from '@angular/router';
import { LocalDate } from '@js-joda/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';
import { Router } from '@angular/router';
import { LocalTime } from "@js-joda/core";
import { NavController } from '@ionic/angular';


@Component({
  selector: 'app-dados',
  templateUrl: './dados.page.html',
  styleUrls: ['./dados.page.scss'],
})



export class DadosPage {





  
  @ViewChild('lineCanvas', { static: true }) lineCanvas!: ElementRef<HTMLCanvasElement>;

  tipoDado: number;
  lineChart: any;
  selectedDados : string = '';
  usuario: Usuario;
  isSubModalOpen = true;  // Controle do novo modal
  dados: Dados[];
  alturas: number[];
  pesos: number[];
  colesterois: number[];
  pressoesMin: number[];
  pressoesMax: number[];
  medida: number[];
  percentual: number[];
  glicose: number[];

  dataInicial: string = '';
  dataFinal: string = '';
  dadosFiltrados: Dados[] = [];
  showCalendarios: boolean = false;


 
  

  


  constructor(
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private formBuilder: FormBuilder,
    private dadosService: DadosService,
    private activatedRoute: ActivatedRoute,
    private usuarioService: UsuarioService,
    private navController: NavController
  ) {
    this.usuario = JSON.parse(localStorage.getItem('usuarioAutenticado') || "");
    Chart.register(...registerables);
    this.tipoDado = 0;

    this.dados = [];
    this.alturas = [];
    this.pesos = [];
    this.colesterois = [];
    this.medida = [];
    this.percentual = [];
    this.pressoesMax = [];
    this.pressoesMin = [];
    this.glicose = [];
  }


  
  ionViewDidEnter() {
    console.log('oi');
  }

  toggleCalendarios() {
    this.showCalendarios = !this.showCalendarios;
  }

  onSelectChange(event: any) {
    this.tipoDado = event.detail.value;
    console.log('Valor selecionado:', event.detail.value);
    this.createLineChart();
  }

  async ionViewWillEnter() {

    this.carregarLista();
    console.log(this.dados);
  }

  async carregarLista() {

    
  
    await this.dadosService.listar(this.usuario.IDUsuario).then((json) => {
      this.dados = <Dados[]>(json);
      console.log('Dados carregados:', this.dados);
      
    });
    this.alturas = this.dados.map((dado) => dado.Altura);
    this.pesos = this.dados.map((dado) => dado.Peso);
    this.colesterois = this.dados.filter((dado) => dado.Colesterol !== 0 && dado.Colesterol !== null).map((dado) => dado.Colesterol);
    this.glicose = this.dados.filter((dado) => dado.Glicose !== 0 && dado.Glicose !== null ).map((dado) => dado.Glicose);
    this.medida = this.dados.filter((dado) => dado.MedidaAbdominal !== 0 && dado.MedidaAbdominal !== null ).map((dado) => dado.MedidaAbdominal);
    this.percentual = this.dados.filter((dado) => dado.PercentualGordura !== 0 && dado.PercentualGordura !== null).map((dado) => dado.PercentualGordura);
    this.pressoesMax = this.dados.filter((dado) => dado.PressaoMax !== 0 && dado.PressaoMin !== 0 && dado.PressaoMax !== null && dado.PressaoMin !== null).map((dado) => dado.PressaoMax);
    this.pressoesMin = this.dados.filter((dado) => dado.PressaoMax !== 0 && dado.PressaoMin !== 0 && dado.PressaoMax !== null && dado.PressaoMin !== null).map((dado) => dado.PressaoMin);
    console.log(this.alturas);
    console.log(this.pesos);
    
  }

  async reload(){
    window.location.reload();
  }


  async createLineChart() {
    
    const dataToUse = this.dadosFiltrados.length > 0 ? this.dadosFiltrados : this.dados;

    if (!this.lineCanvas || !this.lineCanvas.nativeElement) {
      console.error('Canvas element is not available');
      return;
    }
  
    if (this.lineChart) {
      this.lineChart.destroy();
    }
  
    let dataPoints = [0];
    let dataPoints2 = [0];
    let labels = [];
    let tipo = 'Peso';
    labels = dataToUse.map((dado) => dado.DataRegistro);
  
    if (this.tipoDado == 1) {
      dataPoints = this.pesos || [];  // Garantir que não seja undefined
      tipo = 'Peso';
      labels = dataToUse.filter((dado) => dado.Peso !== 0 && dado.Peso !== null).map((dado) => dado.DataRegistro);
      
      
    } else if (this.tipoDado == 2) {
      dataPoints = this.alturas || []; // Garantir que não seja undefined
      tipo = 'Altura';
      labels = dataToUse.filter((dado) => dado.Altura !== 0 && dado.Altura !== null).map((dado) => dado.DataRegistro);
    }
    else if (this.tipoDado == 3) {
      dataPoints = this.colesterois || []; // Garantir que não seja undefined
      tipo = 'Colesterol';
      labels = dataToUse.filter((dado) => dado.Colesterol !== 0 && dado.Colesterol !== null).map((dado) => dado.DataRegistro);
    }
    else if (this.tipoDado == 4) {
      dataPoints = this.percentual || []; // Garantir que não seja undefined
      tipo = 'Percentual de Gordura';
      labels = dataToUse.filter((dado) => dado.PercentualGordura !== 0 && dado.PercentualGordura !== null).map((dado) => dado.DataRegistro);
    }
    else if (this.tipoDado == 5) {
      dataPoints = this.medida || []; // Garantir que não seja undefined
      tipo = 'Medida Abdominal';
      labels = dataToUse.filter((dado) => dado.MedidaAbdominal !== null).map((dado) => dado.DataRegistro);
      console.log(labels);
    }
    else if (this.tipoDado == 6) {
     
      dataPoints = this.pressoesMax || []; // Garantir que não seja undefined
      dataPoints2 = this.pressoesMin || []; // Garantir que não seja undefined
      labels = dataToUse.filter((dado) => dado.PressaoMax !== 0 && dado.PressaoMin !== 0 && dado.PressaoMax !== null && dado.PressaoMin !== null).map((dado) => dado.DataRegistro);
      
      tipo = 'Pressão';
    }else if (this.tipoDado == 7) {
      dataPoints = this.glicose || []; // Garantir que não seja undefined
      tipo = 'Medida Glicose';
      labels = dataToUse.filter((dado) => dado.Glicose !== 0 && dado.Glicose !== null).map((dado) => dado.DataRegistro);
    }
  
    if (!this.dados || this.dados.length === 0) {
      console.error('Dados não disponíveis para criar o gráfico');
      return;
    }
    
    
  
    const backgroundColors = dataPoints.map((_, index) =>
      index === dataPoints.length - 1 ? '#0EB700' : 'gray'
    );
    const borderColors = dataPoints.map((_, index) =>
      index === dataPoints.length - 1 ? '#0EB700' : 'gray'
    );

    const backgroundColors2 = dataPoints2.map((_, index) =>
      index === dataPoints2.length - 1 ? '#0EB700' : 'gray'
    );
    const borderColors2 = dataPoints2.map((_, index) =>
      index === dataPoints2.length - 1 ? '#0EB700' : 'gray'
    );

    
    const datasets = [
      {
        label: tipo,
        fill: false,
        borderColor: borderColors,
        backgroundColor: backgroundColors,
        data: dataPoints,
        pointBackgroundColor: backgroundColors,
        pointBorderColor: borderColors,
      },
    ];
    if (this.tipoDado == 6) {
      // Adicionar dataset para a pressão mínima
      datasets.push({
        label: 'Pressão Mínima',
        fill: false,
        borderColor: borderColors2,
        backgroundColor: backgroundColors2,
        data: dataPoints2,
        pointBackgroundColor: backgroundColors2,
        pointBorderColor: borderColors2,
      });
    }
  
    this.lineChart = new Chart(this.lineCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: labels,
        datasets: datasets,
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  }


  resetarLista(){
    
    this.dadosFiltrados = [];
    this.carregarLista();
    this.createLineChart();
  }

  filtrarPorData() {
    if (this.dataInicial && this.dataFinal) {
      const inicio = new Date(this.dataInicial);
      const fim = new Date(this.dataFinal);
      
      this.dadosFiltrados = this.dados.filter((dado) => {
        const dataRegistro = new Date(dado.DataRegistro);
        return dataRegistro >= inicio && dataRegistro <= fim;
      });
  
      console.log('Dados filtrados:', this.dadosFiltrados);
  
      // Atualizar os dados dos gráficos após o filtro
      this.atualizarDadosFiltrados();
      this.createLineChart();
    } else {
      this.exibirMensagem('Data inicial e/ou data final não selecionada(s).');
    }
  }
  
  atualizarDadosFiltrados() {
    this.alturas = this.dadosFiltrados.map((dado) => dado.Altura);
    this.pesos = this.dadosFiltrados.map((dado) => dado.Peso);
    this.colesterois = this.dadosFiltrados
      .filter((dado) => dado.Colesterol !== 0)
      .map((dado) => dado.Colesterol);
    this.glicose = this.dadosFiltrados
      .filter((dado) => dado.Glicose !== 0)
      .map((dado) => dado.Glicose);
    this.medida = this.dadosFiltrados.map((dado) => dado.MedidaAbdominal);
    this.percentual = this.dadosFiltrados
      .filter((dado) => dado.PercentualGordura !== 0)
      .map((dado) => dado.PercentualGordura);
    this.pressoesMax = this.dadosFiltrados
      .filter((dado) => dado.PressaoMax !== 0 && dado.PressaoMin !== 0)
      .map((dado) => dado.PressaoMax);
    this.pressoesMin = this.dadosFiltrados
      .filter((dado) => dado.PressaoMax !== 0 && dado.PressaoMin !== 0)
      .map((dado) => dado.PressaoMin);
  }


  @ViewChild('popover') popover!: IonPopover;

  // Method to open popover
  openPopover(ev: Event) {
    this.popover.event = ev;
    this.popover.present();
  }

  closePopover() {
    this.popover.dismiss();
  }

  async sair(){
    this.usuarioService.encerrarAutenticacao();
    this.closePopover();
    this.navController.navigateBack('/login');
    
  }


  
  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
  

 

  



  
}
