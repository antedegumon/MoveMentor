import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.page.html',
  styleUrls: ['./cadastro.page.scss'],
})



export class CadastroPage implements OnInit {
  usuario: Usuario;
  formGroup: FormGroup;
  isEditMode: boolean = false;  // Flag para saber se estamos editando

  constructor(
    private formBuilder: FormBuilder,
    private usuarioService: UsuarioService,
    private toastController: ToastController,
    private navController: NavController,
    private activatedRoute: ActivatedRoute,
    private router : Router
  ) {
    this.usuario = new Usuario();
    this.formGroup = this.formBuilder.group({
      'login': [this.usuario.Email, Validators.compose([Validators.required])],
      'senha': [this.usuario.Senha, Validators.compose([Validators.required])],
      'senhaConfirme': [this.usuario.Senha, Validators.compose([Validators.required])],
      'nome': [this.usuario.Nome, Validators.compose([Validators.required])],
      'genero': [this.usuario.Genero, Validators.compose([Validators.required])],
      'data': [this.usuario.DataNascimento, Validators.compose([Validators.required])]
    });
  }

  ngOnInit() {
    // Checar se há um usuário a ser editado
    const usuarioId = this.activatedRoute.snapshot.paramMap.get('idUsuario');
    console.log(usuarioId);
    if (usuarioId) {
      this.isEditMode = true;  // Estamos no modo de edição
      this.loadUsuarioData(usuarioId);
    }
  }

  async goBack(){
    this.navController.navigateBack("/");
  }

  loadUsuarioData(idUsuario: string) {
    // Carregar dados do usuário para edição
    this.usuarioService.buscarPorId(+idUsuario).then((usuario) => {
      this.usuario = usuario;
      this.formGroup.patchValue({
        'login': this.usuario.Email,
        'senha': this.usuario.Senha,
        'senhaConfirme': this.usuario.Senha,
        'nome': this.usuario.Nome,
        'genero': this.usuario.Genero,
        'data': this.usuario.DataNascimento
      });
    });
  }

  autenticar() {
    if (this.formGroup.valid) {
      const { login, senha, senhaConfirme, nome, genero, data } = this.formGroup.value;

      if (senha !== senhaConfirme) {
        this.exibirMensagem('As senhas não conferem');
        return;
      }

      this.usuario.Nome = nome;
      this.usuario.Email = login;
      this.usuario.Senha = senha;
      this.usuario.DataNascimento = data;
      this.usuario.Genero = genero;

      console.log(this.usuario);
      // Checar se estamos editando ou criando um novo usuário
      if (this.isEditMode) {
        
        this.usuarioService.atualizar(this.usuario)
        .then(() => {
          this.exibirMensagem('Usuário atualizado com sucesso!');
          setTimeout(() =>{
            this.usuarioService.registrarAutenticacao(this.usuario);
            this.router.navigate(['/tabs/inicio']); 
          },1000)
        })
          .catch((erro) => this.exibirMensagem('Erro ao atualizar: ' + erro));
      } else {
        console.log(this.usuario);
        this.usuarioService.salvar(this.usuario)
          .then(() => {
            this.exibirMensagem('Usuário cadastrado com sucesso!');
            setTimeout(() =>{
              this.router.navigate(['/login']); 
            },1000)
          })
          .catch((erro) => this.exibirMensagem('Erro ao cadastrar: ' +  this.usuario + erro));
          console.log(this.usuario);
          
      }
    }
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}
