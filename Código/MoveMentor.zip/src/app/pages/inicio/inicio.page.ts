import { Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { IonPopover } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Treino } from 'src/app/model/treino';
import { TreinoService } from 'src/app/services/treino.service';
import { FichaService } from 'src/app/services/ficha.service';
import { ExercicioService } from 'src/app/services/exercicio.service';
import { Fichaexercicio } from 'src/app/model/fichaexercicio';
import { FichaexercicioService } from 'src/app/services/fichaexercicio.service';
import { Corrida } from 'src/app/model/corrida';
import { CorridaService } from 'src/app/services/corrida.service';
import { Exercicio } from 'src/app/model/exercicio';
import { ActivatedRoute } from '@angular/router';
import { LocalDate } from '@js-joda/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Usuario } from 'src/app/model/usuario';
import { UsuarioService } from 'src/app/services/usuario.service';
import { Router } from '@angular/router';
import { LocalTime } from "@js-joda/core";
import { NavController } from '@ionic/angular';
import { Chart, registerables } from 'chart.js/auto';
import { Dados } from 'src/app/model/dados';
import { DadosService } from 'src/app/services/dados.service';


@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {
  
  @ViewChild('lineCanvas', { static: true }) lineCanvas!: ElementRef<HTMLCanvasElement>;


  lineChart: any;
  dados : any[] = [];
  usuario : any = {};
  isSubModalOpen = true;  // Controle do novo modal
  alturas: number[] = [];
  pesos: number[] = [];
  imcs: number[] = [];
  imc: number;
  datas: string[] = [];

  dataInicial: string = '';
  dataFinal: string = '';
  showCalendarios: boolean = false;

  weekDays: string[] = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  weekDates: string[] = [];
  treinosSemana: (Treino | null)[] = [];
  corridasSemana: (Corrida | null)[] = [];
  today: string;


  constructor(
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private formBuilder: FormBuilder,
    private corridaService: CorridaService,
    private exercicioService: ExercicioService,
    private activatedRoute: ActivatedRoute,
    private fichaexercicioService: FichaexercicioService,
    private treinoService: TreinoService,
    private usuarioService: UsuarioService,
    private navController: NavController,
    private dadosService: DadosService,
    
  ) {
   
    const usuarioLocal = localStorage.getItem('usuarioAutenticado');
    
    if (usuarioLocal) {
      this.usuario = JSON.parse(usuarioLocal);
    } else {
      // Criar um usuário genérico se não houver um autenticado
      //this.usuario = { idUsuario: '-1', nome: 'Convidado' };
      //localStorage.setItem('usuarioAutenticado', JSON.stringify(this.usuario));
      this.navController.navigateForward('/login');
    }
    this.imcs = [];
    this.imc = 0;

//<p *ngIf="corrida !== null">{{ corrida.Distancia }}</p> 
this.today = this.formatDate(new Date());
    this.generateWeekData();

   }

   async generateWeekData() {
    let today = new Date();
    let currentDay = today.getDay(); // Índice do dia da semana (0 = Domingo, 6 = Sábado)
    let startDate = new Date(today);
    startDate.setDate(today.getDate() - currentDay); // Define o início da semana (domingo)

    for (let i = 0; i < 7; i++) {
      let date = new Date(startDate);
      date.setDate(startDate.getDate() + i);

      // Formatar para yyyy-MM-dd
      
      let formattedDate = this.formatDate(date);

      // Formatar para exibição na tabela (DD/MM)
      let day = date.getDate().toString().padStart(2, '0');
      let month = (date.getMonth() + 1).toString().padStart(2, '0');
      this.weekDates.push(`${this.weekDays[i]} ${day}/${month}`);

      // Busca treino na data e armazena
      
      this.treinosSemana.push(await this.treinoService.buscarPorData(formattedDate, this.usuario.IDUsuario));
      this.corridasSemana.push(await this.corridaService.buscarPorData(formattedDate, this.usuario.IDUsuario));
    }

    
    
  }

  formatDate(date: Date): string {
    
    let year = new Date().getFullYear();
    
    let month = (date.getMonth() + 1).toString().padStart(2, '0');
    let day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  // Simula busca de treino por data (substitua pela sua função real)

  getCorridaImage(index: number): string {

    if (!this.weekDates || !this.weekDates[index]) {
      return "assets/icon/corridaD.png"; // Retorna a imagem cinza se a data não estiver disponível
    }
    let date = this.formatDate(new Date(this.weekDates[index].split(' ')[1].split('/').reverse().join('-')));
    //console.log(date +' '+this.today);
    if (date > this.today) {
      return "assets/icon/corridaD.png"; // Futuro (cinza)
    }
    return this.corridasSemana[index] !== null ? "assets/icon/corridaS.png" : "assets/icon/corridaN.png";
  }

  /**
   * Retorna a imagem correta para treino, dependendo se já passou ou não
   */
  getTreinoImage(index: number): string {

    if (!this.weekDates || !this.weekDates[index]) {
      return "assets/icon/treinoD.png"; // Retorna a imagem cinza se a data não estiver disponível
    }
    let date = this.formatDate(new Date(this.weekDates[index].split(' ')[1].split('/').reverse().join('-')));
    if (date > this.today) {
      return "assets/icon/treinoD.png"; // Futuro (cinza)
    }
    return this.treinosSemana[index] !== null ? "assets/icon/treinoS.png" : "assets/icon/treinoN.png";
  }
  

  


  ionViewWillEnter(){
    
  }

  @ViewChild('popover') popover!: IonPopover;

  // Method to open popover
  openPopover(ev: Event) {
    this.popover.event = ev;
    this.popover.present();
  }

  closePopover() {
    this.popover.dismiss();
  }


  editarUsuario() {
    this.closePopover();
    this.navController.navigateForward(`/cadastro/${this.usuario.IDUsuario}`);
  }
  
  async reload(){
    window.location.reload();
  }
  
  async sair() {
    localStorage.removeItem('usuarioAutenticado');
    localStorage.clear(); // Limpa o localStorage
    sessionStorage.clear(); 
    this.closePopover();
    
    this.router.navigate(['/login'], { replaceUrl: true });
  }

  ngOnInit(): void {
    this.carregarLista();
  }

  async carregarLista() {
    try {
      this.dados = await this.dadosService.listar(this.usuario.IDUsuario);
      if (!this.dados || this.dados.length === 0) {
        console.warn('Nenhum dado encontrado para o usuário');
        return;
      }


      this.datas = this.dados.map((dado) => dado.DataRegistro);
      this.alturas = this.dados.map((dado) => dado.Altura);
      this.pesos = this.dados.map((dado) => dado.Peso);
  
      this.imcs = this.alturas.map((altura, index) => {
        const peso = this.pesos[index];
        return altura > 0 ? peso / (altura * altura) : 0;
      });
  
      this.imc = this.imcs[this.imcs.length - 1];
      

      this.createLineChart();
    } catch (error) {
      console.error('Erro ao carregar lista de dados:', error);
    }
  }
  

  createLineChart() {
    if (!this.lineCanvas || !this.lineCanvas.nativeElement) {
      console.error('Canvas element is not available');
      return;
    }

    if (this.lineChart) {
      this.lineChart.destroy();
    }

    let dataPoints = this.imcs || [];
    let labels = this.datas || [];

    if (!dataPoints.length || !labels.length) {
      console.error('Dados insuficientes para criar o gráfico');
      return;
    }

    const backgroundColors = dataPoints.map((_, index) =>
      index === dataPoints.length - 1 ? '#0EB700' : 'gray'
    );
    const borderColors = dataPoints.map((_, index) =>
      index === dataPoints.length - 1 ? '#0EB700' : 'gray'
    );


    this.lineChart = new Chart(this.lineCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'IMC',
            fill: false,
            borderColor: borderColors,
            backgroundColor: backgroundColors,
            data: dataPoints,
            pointBackgroundColor: backgroundColors,
            pointBorderColor: borderColors,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  }

  filtrarPorData() {
    if (this.dataInicial && this.dataFinal) {
      const inicio = new Date(this.dataInicial);
      const fim = new Date(this.dataFinal);

      
      
      let dadosFiltrados = this.dados.filter((dado) => {
        const dataRegistro = new Date(dado.DataRegistro);
        
        return dataRegistro >= inicio && dataRegistro <= fim;
      });

   
      
  
      // Atualizar os dados dos gráficos após o filtro
      this.atualizarDadosFiltrados(dadosFiltrados);
      this.createLineChart();
    } else {
      this.exibirMensagem('Data inicial e/ou data final não selecionada(s).');
    }
  }
  
  atualizarDadosFiltrados(dadosFiltrados : any[]) {
    this.datas = dadosFiltrados.map((dado) => dado.DataRegistro);
    this.alturas = dadosFiltrados.map((dado) => dado.Altura);
    this.pesos = dadosFiltrados.map((dado) => dado.Peso);

    this.imcs = this.alturas.map((altura, index) => {
      const peso = this.pesos[index];
      return altura > 0 ? peso / (altura * altura) : 0;
    });
  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 1500
    });
    toast.present();
  }
}