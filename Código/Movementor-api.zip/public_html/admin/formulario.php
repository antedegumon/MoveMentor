<?php
// Verifica se estamos editando (se veio um ID na URL)
$idExercicio = isset($_GET['id']) ? intval($_GET['id']) : null;
$exercicio = null;


if ($idExercicio) {
    // Busca o exercício da API para edição
    $url = "https://teal-mink-565589.hostingersite.com/exercicio/byid/".$idExercicio;
    $response = file_get_contents($url);
    if ($response) {
        $exercicio = json_decode($response, true); // Transforma JSON em array associativo



        echo $exercicio;
    } else {
        echo "Erro: Não foi possível carregar os dados do exercício.";
        echo "<script>alert('Operação falha!');</script>";
        exit;
    }
}
?>


<style>
    /* Reset básico */
/* Reset básico */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: linear-gradient(to top, #000000, #22222c);
    color: #ffffff;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 20px;
}

h1 {
    color: #0EB700;
    margin-bottom: 20px;
}

a {
    color: #0EB700;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s ease;
}

a:hover {
    color: rgba(71, 71, 71, 0.8);
}

form {
    background: #1c1c24;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    width: 50%;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

label {
    font-weight: bold;
    color: #0EB700;
}

input, textarea, select {
    width: 100%;
    padding: 10px;
    background: #2a2a36;
    border: 1px solid rgba(71, 71, 71, 0.541);
    color: #ffffff;
    border-radius: 5px;
}

select {
    appearance: none;
    cursor: pointer;
    padding-right: 30px;
    background-image: url('data:image/svg+xml;utf8,<svg fill="white" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
    background-repeat: no-repeat;
    background-position: right 10px center;
    background-size: 20px;
}

select:focus {
    border-color: #0EB700;
    outline: none;
}

button {
    background: #0EB700;
    color: #ffffff;
    padding: 10px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s ease;
}

button:hover {
    background: rgba(71, 71, 71, 0.8);
}

img {
    max-width: 200px;
    max-height: 200px;
    border-radius: 5px;
    margin-top: 10px;
}

#descricao, #instrucoes {
    width: 100%;
    height: 15vh;
    resize: none;
}

.btn-voltar {
        background-color: #0EB700;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background 0.3s ease;
        position: absolute;
        top: 3vh;
        left: 3vw;
    }

    .btn-voltar:hover {
        background-color: rgba(71, 71, 71, 0.8);
    }


</style>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Exercício</title>
</head>
<body>
    <button class="btn-voltar" onclick="window.history.back()">Voltar</button>
    <h1><?= $idExercicio ? 'Editar Exercício' : 'Cadastrar Exercício' ?></h1>

    <form action="salvar_exercicio.php" method="POST" enctype="multipart/form-data">
        <!-- Campo oculto para o ID (usado na edição) -->
        <?php if ($idExercicio): ?>
            <input type="hidden" name="idExercicio" value="<?= htmlspecialchars($exercicio['IDExercicio']) ?>">
        <?php endif; ?>

        <!-- Nome -->
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($exercicio['Nome'] ?? '') ?>" required>
        <br><br>

        <!-- Descrição -->
        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao" required><?= htmlspecialchars($exercicio['Descricao'] ?? '') ?></textarea>
        <br><br>
        
        <?php
            error_reporting(E_ALL);
            ini_set('display_errors', 1);


            $host = 'localhost';
            $dbname = 'u245691198_movementor';
            $username = 'u245691198_cefet';
            $password = 'Cefet2022';
            
            try {
                $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
                echo "Erro ao conectar ao banco de dados: " . $e->getMessage();
                exit;
            }
                
               
        global $pdo;
        $sql = "SELECT * FROM Categoria";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        
            ?>

        <!-- Categoria -->
        <label for="categoria">Categoria:</label>
        <select id="categoria" name="categoria" required>
            <option value="" disabled selected>Selecione uma categoria</option>
            <?php foreach ($categorias as $categoria): ?>
                <option value="<?= htmlspecialchars($categoria['id']) ?>">
                <?= htmlspecialchars($categoria['Nome']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br><br>

        <!-- Imagem -->
        <label for="imagem">Imagem:</label>
        <?php if ($idExercicio && !empty($exercicio['Imagem'])): ?>
            <!-- Exibe a imagem atual -->
            <div>
                <img src="<?= htmlspecialchars($exercicio['Imagem']) ?>" alt="Imagem do exercício" style="max-width: 200px; max-height: 200px;">
            </div>
        <?php endif; ?>
        <input type="file" id="imagem" name="imagem" accept="image/*">
        <br><br>

        <!-- Instruções -->
        <label for="instrucoes">Instruções:</label>
        <textarea id="instrucoes" name="instrucoes" required><?= htmlspecialchars($exercicio['Instrucoes'] ?? '') ?></textarea>
        <br><br>

        <!-- Flag -->
        <label for="flag">Ativo:</label>
        <input type="checkbox" id="flag" name="flag" value="1" <?= isset($exercicio['Flag']) && $exercicio['Flag'] ? 'checked' : '' ?>>
        <br><br>

        <button type="submit">Salvar</button>
    </form>
    

</body>
</html>
