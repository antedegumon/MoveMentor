<?php
session_start();
require_once 'api.php';

$api = new API('https://teal-mink-565589.hostingersite.com/exercicio');
$exercicios = $api->get('/');

?>
<!DOCTYPE html>
<style>
    /* Reset básico */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: linear-gradient(to top, #000000, #22222c);
    color: #ffffff;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 20px;
}

h1 {
    color: #0EB700;
    margin-bottom: 20px;
}

a {
    color: #0EB700;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s ease;
}

a:hover {
    color: rgba(71, 71, 71, 0.8);
}

table {
    width: 80%;
    border-collapse: collapse;
    background: #1c1c24;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

thead {
    background: #0EB700;
    color: #ffffff;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid rgba(71, 71, 71, 0.541);
}

tbody tr:hover {
    background: rgba(71, 71, 71, 0.541);
}

td a {
    margin-right: 10px;
    padding: 6px 12px;
    border-radius: 5px;
    background: #0EB700;
    color: #fff;
    font-size: 14px;
    transition: background 0.3s ease;
}

td a:hover {
    background: rgba(71, 71, 71, 0.8);
}
</style>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Exercícios</title>
</head>
<body>
    <?php include_once("menu.php");?>
    <h1>Lista de Exercícios</h1>
    <a href="formulario.php">Cadastrar Novo Exercício</a>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($exercicios as $exercicio): ?>
                <tr>
                    <td><?= htmlspecialchars($exercicio['IDExercicio']) ?></td>
                    <td><?= htmlspecialchars($exercicio['Nome']) ?></td>
                    <td><?= htmlspecialchars($exercicio['Descricao']) ?></td>
                    <td>
                        <a href="formulario.php?id=<?= htmlspecialchars($exercicio['IDExercicio']) ?>">Editar</a>
                        <a href="excluir_exercicio.php?id=<?= htmlspecialchars($exercicio['IDExercicio']) ?>">Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
