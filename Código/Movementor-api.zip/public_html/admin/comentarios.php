<?php
session_start();

// Função para buscar o nome do usuário
function getUsuarioNome($idUsuario) {
    $url = "https://teal-mink-565589.hostingersite.com/usuario/byid/{$idUsuario}";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);

    $usuario = json_decode($response, true);
    return $usuario['Nome'] ?? 'Desconhecido';
}

// Função para buscar o nome do exercício
function getExercicioNome($idExercicio) {
    $url = "https://teal-mink-565589.hostingersite.com/exercicio/byid/{$idExercicio}";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);

    $exercicio = json_decode($response, true);
    return $exercicio['Nome'] ?? 'Desconhecido';
}

// URL da API para buscar os comentários
$url = 'https://teal-mink-565589.hostingersite.com/comentario';

// Inicializa cURL
$curl = curl_init($url);

// Configura as opções de cURL
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// Executa a requisição
$response = curl_exec($curl);

// Verifica se houve erro na requisição
if ($response === false) {
    die('Erro na requisição: ' . curl_error($curl));
}

// Fecha a conexão cURL
curl_close($curl);

// Decodifica a resposta JSON
$comentarios = json_decode($response, true);

// Verifica se a resposta é um array
if (!is_array($comentarios)) {
    die('Erro ao decodificar os dados.');
}

// Aplicar filtros se existirem
if (isset($_GET['lido']) || isset($_GET['resolvido'])) {
    $lidoFiltro = $_GET['lido'] !== '' ? $_GET['lido'] : null;
    $resolvidoFiltro = $_GET['resolvido'] !== '' ? $_GET['resolvido'] : null;

    $comentariosFiltrados = array_filter($comentarios, function($comentario) use ($lidoFiltro, $resolvidoFiltro) {
        $lidoCond = $lidoFiltro !== null ? $comentario['Lido'] == $lidoFiltro : true;
        $resolvidoCond = $resolvidoFiltro !== null ? $comentario['Resolvido'] == $resolvidoFiltro : true;
        return $lidoCond && $resolvidoCond;
    });
} else {
    $comentariosFiltrados = $comentarios; // Nenhum filtro aplicado
}

// Início do HTML
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Comentários</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Reset básico */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: linear-gradient(to top, #000000, #22222c);
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }

        h2 {
            color: #0EB700;
            margin-bottom: 20px;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            background: #1c1c24;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        thead {
            background: #0EB700;
            color: #ffffff;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid rgba(71, 71, 71, 0.541);
        }

        tbody tr:hover {
            background: rgba(71, 71, 71, 0.541);
        }

        .icon {
            width: 20px;
            height: 20px;
        }

        td img {
            vertical-align: middle; /* Alinha os ícones ao centro da célula */
        }

        .button {
            display: inline-block;
            margin-left: 10px;
            padding: 5px 10px;
            background-color: #0EB700;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }

        .button:hover {
            background-color: #0a9d00;
        }
    </style>
</head>
<body>
    <?php include_once("menu.php");?>

    <h2>Lista de Comentários</h2>

    <form method="GET" action="">
        <label for="lido">Filtrar por Lido:</label>
        <select name="lido" id="lido">
            <option value="">Todos</option>
            <option value="1" <?= isset($_GET['lido']) && $_GET['lido'] == '1' ? 'selected' : ''; ?>>Lido</option>
            <option value="0" <?= isset($_GET['lido']) && $_GET['lido'] == '0' ? 'selected' : ''; ?>>Não Lido</option>
        </select>

        <label for="resolvido">Filtrar por Resolvido:</label>
        <select name="resolvido" id="resolvido">
            <option value="">Todos</option>
            <option value="1" <?= isset($_GET['resolvido']) && $_GET['resolvido'] == '1' ? 'selected' : ''; ?>>Resolvido</option>
            <option value="0" <?= isset($_GET['resolvido']) && $_GET['resolvido'] == '0' ? 'selected' : ''; ?>>Não Resolvido</option>
        </select>

        <button type="submit">Aplicar Filtros</button>
        <a href="comentarios.php" class="button">Limpar Filtros</a>
    </form>

    <table>
        <thead>
            <tr>
                <th>Nome Usuário</th>
                <th>Nome Exercício</th>
                <th>Comentário</th>
                <th>Lido</th>
                <th>Resolvido</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($comentariosFiltrados as $comentario): 
                $usuarioNome = getUsuarioNome($comentario['IDUsuario']);
                $exercicioNome = getExercicioNome($comentario['IDExercicio']);
            ?>
            <tr onclick="window.location.href='visualizarcomentario.php?id=<?= $comentario['IDComentario'] ?>'">
                <td><?php echo htmlspecialchars($usuarioNome); ?></td>
                <td><?php echo htmlspecialchars($exercicioNome); ?></td>
                <td><?php echo htmlspecialchars($comentario['Comentario']); ?></td>
                <td>
                    <?php if ($comentario['Lido']): ?>
                        <img src="uploads/sim.webb" alt="Lido" class="icon">
                    <?php else: ?>
                        <img src="uploads/nao.png" alt="Não Lido" class="icon">
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($comentario['Resolvido']): ?>
                        <img src="uploads/sim.webb" alt="Resolvido" class="icon">
                    <?php else: ?>
                        <img src="uploads/nao.png" alt="Não Resolvido" class="icon">
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
