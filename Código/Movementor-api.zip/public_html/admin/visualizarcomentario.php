<style>
    /* Reset básico */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: linear-gradient(to top, #000000, #22222c);
    color: #ffffff;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 20px;
}

h2 {
    color: #0EB700;
    margin-bottom: 20px;
}

.form-container {
    background: #1c1c24;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    width: 80%;
    max-width: 600px;
}

form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label {
    font-weight: bold;
    font-size: 14px;
    color: #0EB700;
}

input, textarea {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background: #2a2a36;
    color: #ffffff;
    font-size: 16px;
}

input:focus, textarea:focus {
    outline: 2px solid #0EB700;
}

.status {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 16px;
}

.icon {
    width: 20px;
    height: 20px;
    vertical-align: middle;
}

button {
    background: #0EB700;
    color: #ffffff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.3s ease;
}

button:hover {
    background: rgba(71, 71, 71, 0.8);
}

a {
    color: #0EB700;
    text-decoration: none;
    font-weight: bold;
    margin-top: 15px;
    display: inline-block;
    transition: color 0.3s ease;
}

a:hover {
    color: rgba(71, 71, 71, 0.8);
}

</style>
<?php
if (!isset($_GET['id'])) {
    die("ID do comentário não fornecido.");
}

$idComentario = $_GET['id'];
$comentario = json_decode(file_get_contents("https://teal-mink-565589.hostingersite.com/comentario/byid/$idComentario"), true);

// Buscar nome do usuário
$idUsuario = $comentario['IDUsuario'];
$usuario = json_decode(file_get_contents("https://teal-mink-565589.hostingersite.com/usuario/byid/$idUsuario"), true);
$nomeUsuario = $usuario['Nome'] ?? 'Desconhecido';

// Buscar nome do exercício
$idExercicio = $comentario['IDExercicio'];
$exercicio = json_decode(file_get_contents("https://teal-mink-565589.hostingersite.com/exercicio/byid/$idExercicio"), true);
$nomeExercicio = $exercicio['Nome'] ?? 'Desconhecido';

// Se for a primeira vez que a página for aberta, marcar como lido
if (!$comentario['Lido']) {
    $comentario['Lido'] = true;
    $data = json_encode([
        "IDComentario" => $comentario['IDComentario'],
        "Lido" => true,
        "Resolvido" => $comentario['Resolvido']
    ]);

    $ch = curl_init("https://teal-mink-565589.hostingersite.com/comentario");
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_exec($ch);
    curl_close($ch);
}

// Função para marcar como resolvido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comentario['Resolvido'] = true;
    $data = json_encode([
        "IDComentario" => $comentario['IDComentario'],
        "Lido" => true,
        "Resolvido" => true
    ]);

    $ch = curl_init("https://teal-mink-565589.hostingersite.com/comentario");
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_exec($ch);
    curl_close($ch);

    header("Location: visualizarcomentario.php?id=$idComentario");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Comentário</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<h2>Detalhes do Comentário</h2>

<div class="form-container">
    <form method="POST">
        <label>Nome do Usuário:</label>
        <input type="text" value="<?= htmlspecialchars($nomeUsuario) ?>" readonly>

        <label>ID do Exercício:</label>
        <input type="text" value="<?= htmlspecialchars($idExercicio) ?>" readonly>

        <label>Nome do Exercício:</label>
        <input type="text" value="<?= htmlspecialchars($nomeExercicio) ?>" readonly>

        <label>Comentário:</label>
        <textarea readonly><?= htmlspecialchars($comentario['Comentario']) ?></textarea>

        <label class="status">Lido: ✅</label>

        <label class="status">Resolvido: <?= $comentario['Resolvido'] ? '✅' : '❌' ?></label>

        <?php if (!$comentario['Resolvido']): ?>
            <button type="submit">Marcar como Resolvido</button>
        <?php endif; ?>
    </form>
</div>

<a href="comentarios.php">Voltar</a>

</body>
</html>
