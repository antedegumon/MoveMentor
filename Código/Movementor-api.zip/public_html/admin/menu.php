<!-- menu.php -->

<?php
 if (!isset($_SESSION["usuarioAutenticado"])) {
        header("Location: login.php"); // Redireciona para a página de login
        exit();
    }
?>
<nav class="navbar">
    <ul>
        <li><a href="index.php">Exercícios</a></li>
        <li><a href="comentarios.php">Comentários</a></li>
    </ul>
    <button class="logout-btn" onclick="logout()">Logout</button>
</nav>

<script>
    function logout() {
        // Remove os dados do usuário do localStorage e redireciona para a página de login
        localStorage.removeItem('usuarioAutenticado');
        window.location.href = "login.php";
    }
</script>

<style>
    /* Reset básico */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, sans-serif;
    }

    /* Barra de navegação */
    .navbar {
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #1c1c24;
        padding: 15px 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1000;
    }

    .navbar ul {
        list-style: none;
        display: flex;
        gap: 20px;
    }

    .navbar ul li {
        display: inline;
    }

    .navbar a {
        text-decoration: none;
        color: #0EB700;
        font-size: 18px;
        font-weight: bold;
    }

    .navbar a:hover {
        color: #ffffff;
    }

    /* Botão de logout */
    .logout-btn {
        background: #d9534f;
        color: white;
        border: none;
        padding: 8px 15px;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
    }

    .logout-btn:hover {
        background: #c9302c;
    }
</style>
