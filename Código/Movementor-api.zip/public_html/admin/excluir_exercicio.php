<?php

if ($_SERVER['REQUEST_METHOD'] === 'GET' ) {
    $idExercicio = isset($_GET['id']) ? intval($_GET['id']) : null;
    

    // Upload da imagem
   
    // Dados do exercício
    
    
    echo 'id: '.$idExercicio;

    

    // Define a URL da API
    $url = "https://teal-mink-565589.hostingersite.com/exercicio/".$idExercicio;
    $method = 'DELETE';

    // Faz a requisição usando cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 || $httpCode === 201) {
        header("Location: index.php");
    } else {
        echo "Erro ao excluir exercício: $response";
    }
}
?>
