<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    // Criar a URL de autenticação
    $url = "https://teal-mink-565589.hostingersite.com/adm/autenticar/$email/$senha";

    // Fazer a requisição para a URL
    $response = file_get_contents($url);
    
    // Aqui, você pode verificar a resposta e ajustar conforme necessário.
    // Supondo que a resposta seja um JSON com os dados do usuário.
    $user = json_decode($response, true);

    if ($user && isset($user['IDAdm'])) {
        // Armazena os dados do usuário na sessão
        $_SESSION["usuarioAutenticado"] = [
            "IDAdm" => $user["IDAdm"],
            "Nome" => $user["Nome"],
            "NivelAcesso" => $user["NivelAcesso"]
        ];
        header("Location: index.php");
        exit();
    } else {
        $erro = "Email ou senha inválidos!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="login-container">
        <h2>Login</h2>
        <?php if (isset($erro)) : ?>
            <p class="erro"><?= htmlspecialchars($erro) ?></p>
        <?php endif; ?>
        <form method="POST">
            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Senha:</label>
            <input type="password" name="senha" required>

            <button type="submit">Entrar</button>
        </form>
    </div>

</body>
</html>

<style>
    body {
        background: linear-gradient(to top, #000000, #22222c);
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        font-family: Arial, sans-serif;
    }

    .login-container {
        background: #1c1c24;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        width: 300px;
        text-align: center;
    }

    h2 {
        color: #0EB700;
        margin-bottom: 20px;
    }

    .erro {
        color: #d9534f;
        font-size: 14px;
        margin-bottom: 10px;
    }

    label {
        display: block;
        text-align: left;
        margin: 10px 0 5px;
    }

    input {
        width: 100%;
        padding: 8px;
        border: 1px solid #0EB700;
        border-radius: 5px;
        background: #333;
        color: white;
    }

    button {
        background: #0EB700;
        color: white;
        border: none;
        padding: 10px;
        width: 100%;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
        margin-top: 15px;
    }

    button:hover {
        background: #0a9200;
    }
</style>
