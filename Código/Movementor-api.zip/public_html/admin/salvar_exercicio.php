<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idExercicio = isset($_POST['idExercicio']) ? intval($_POST['idExercicio']) : null;
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $idCategoria = intval($_POST['categoria']);
    $instrucoes = $_POST['instrucoes'];
    $flag = isset($_POST['flag']) ? true : false;
    echo $idCategoria;
    echo '<br>';
    echo $nome;

    // Upload da imagem
    $imagemUrl = null;
    if (!empty($_FILES['imagem']['name'])) {
        $uploadDir = 'uploads/';
        $uploadFile = $uploadDir . basename($_FILES['imagem']['name']);

        if (move_uploaded_file($_FILES['imagem']['tmp_name'], $uploadFile)) {
            $imagemUrl = "https://teal-mink-565589.hostingersite.com/admin/uploads/" . basename($_FILES['imagem']['name']);
        } else {
            die("Erro ao fazer upload da imagem.");
        }
    }

    // Dados do exercício
    $data = [
        'IDExercicio' => $idExercicio,
        'Nome' => $nome,
        'Descricao' => $descricao,
        'IDCategoria' => $idCategoria,
        'Imagem' => $imagemUrl,
        'Instrucoes' => $instrucoes,
        'Flag' => $flag
    ];
    
    echo $data;

    // Converte os dados para JSON
    $jsonData = json_encode($data);

    // Define a URL da API
    $url = "https://teal-mink-565589.hostingersite.com/exercicio";
    $method = $idExercicio ? 'PUT' : 'POST';

    // Faz a requisição usando cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 || $httpCode === 201) {
        header("Location: index.php");
    } else {
        echo "Erro ao salvar exercício: $response";
    }
}
?>
