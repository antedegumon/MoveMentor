<?php

require_once './config/db.php';

class CorridaController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Corrida WHERE Flag = 1 ORDER BY DataRealizada";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($IDCorrida) {
        
        global $pdo;
        $sql = "SELECT * FROM Corrida WHERE IDCorrida = :IDCorrida";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDCorrida', $IDCorrida);
        $stmt->execute();
        $corrida = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$corrida) {
            return ['message' => 'Corrida não encontrado'];
        }
        
        return $corrida;
    }
    
    public function getByDate($Data, $IDUsuario) {
        
        global $pdo;
        $sql = "SELECT * FROM Corrida WHERE DataRealizada = :DataRealizada AND IDUsuario = :IDUsuario AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':DataRealizada', $Data);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->execute();
        $corrida = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$corrida) {
            return null;
        }
        
        return $corrida;
    }

public function getAllByUsu($IDUsu) {
        
        global $pdo;
        $sql = "SELECT * FROM Corrida WHERE IDUsuario = :IDUsuario AND Flag =1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDUsuario', $IDUsu);
        $stmt->execute();
        $corrida = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$corrida) {
            return ['message' => 'Corrida não encontrado'];
        }
        
        return $corrida;
    }
    public function getAllByName($Descricao) {
        global $pdo;
        $sql = "SELECT * FROM Corrida WHERE Descricao LIKE :Descricao AND flag = 1 ORDER BY DataRealizada";
        $stmt = $pdo->prepare($sql);
        $nome = "%$Descricao%";
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

   

    public function registrar($IDUsuario, $Descricao, $Distancia, $Tempo, $DataRealizada, $Calorias) {
    global $pdo;

    // Verificando se a corrida já existe com a mesma descrição
    $sql = "SELECT * FROM Corrida WHERE Descricao = :Descricao AND Flag = 1";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':Descricao', $Descricao);
    $stmt->execute();

    if ($stmt->fetch(PDO::FETCH_ASSOC)) {
        return ['message' => 'Corrida já cadastrada'];
    }

    // Inserindo a nova corrida
    $sql = "INSERT INTO Corrida (IDUsuario, Descricao, Distancia, Tempo, DataRealizada, Calorias, Flag) 
            VALUES (:IDUsuario, :Descricao, :Distancia, :Tempo, :DataRealizada, :Calorias, 1)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':IDUsuario', $IDUsuario);
    $stmt->bindParam(':Descricao', $Descricao);
    $stmt->bindParam(':Distancia', $Distancia);
    $stmt->bindParam(':Tempo', $Tempo);
    $stmt->bindParam(':DataRealizada', $DataRealizada);
    $stmt->bindParam(':Calorias', $Calorias);
    $stmt->execute();

    // Criando o objeto diretamente, sem nova consulta ao banco
    return [
        "IDCorrida" => $pdo->lastInsertId(), // Obtém o ID inserido
        "IDUsuario" => $IDUsuario,
        "Distancia" => $Distancia,
        "Tempo" => $Tempo,
        "DataRealizada" => $DataRealizada,
        "Calorias" => $Calorias,
        "Descricao" => $Descricao,
        "Flag" => 1
    ];
}


    public function update($IDCorrida, $IDUsuario, $Descricao, $Distancia, $Tempo, $DataRealizada, $Calorias) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Corrida WHERE IDCorrida = :IDCorrida AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDCorrida', $IDCorrida);
        $stmt->execute();
        $exercicio = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$exercicio) {
            return ['message' => 'Corrida não encontrado'];
        }

        // Atualizando o usuário
        
        $sql = "UPDATE Corrida SET Descricao = :Descricao
                WHERE IDCorrida = :IDCorrida AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->execute();

        return true;
    }

    public function delete($IDCorrida) {
        global $pdo;


        // Deletando o usuário (na verdade, desativando)
        $sql = "UPDATE Corrida SET flag = 0 WHERE IDCorrida = :IDCorrida AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDCorrida', $IDCorrida);
        return $stmt->execute();
    }
}

?>