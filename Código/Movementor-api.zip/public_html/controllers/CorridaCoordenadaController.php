<?php

//require_once './model/FichaExercicio.php';
require_once './config/db.php';

class CorridaCoordenadaController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM CoordenadaCorrida ORDER BY Ordem";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    
    
    public function getByCorrida($IDCorrida) {
        global $pdo;
        $sql = "SELECT * FROM CoordenadaCorrida WHERE IDCorrida = :IDCorrida ORDER BY Ordem";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDCorrida', $IDCorrida);
        $stmt->execute();
        $coordenada = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$coordenada) {
            return ['message' => 'Coordenada não encontrado'];
        }
        
        return $coordenada;
    }

   

   

    public function registrar($IDCorrida, $Ordem, $Latitude, $Longitude) {
        global $pdo;

      
       
        $sql = "INSERT INTO CoordenadaCorrida (IDCorrida, Ordem, Latitude, Longitude) 
                VALUES (:IDCorrida, :Ordem, :Latitude, :Longitude)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDCorrida', $IDCorrida);
        $stmt->bindParam(':Ordem', $Ordem);
        $stmt->bindParam(':Latitude', $Latitude);
        $stmt->bindParam(':Longitude', $Longitude);
        $stmt->execute();

        return $pdo->lastInsertId();
    }

   

    public function delete($IDCorrida) {
        global $pdo;

        

        // Deletando o usuário (na verdade, desativando)
        $sql = "DELETE FROM CoordenadaCorrida WHERE IDCorrida = :IDCorrida";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDCorrida', $IDCorrida);
        return $stmt->execute();
    }
}

?>