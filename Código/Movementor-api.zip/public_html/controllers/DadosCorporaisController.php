<?php

require_once './config/db.php';

class DadosCorporaisController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM DadosCorporais WHERE flag = 1 ORDER BY DataRegistro";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($IDDadosCorporais) {
        
        global $pdo;
        $sql = "SELECT * FROM DadosCorporais WHERE IDDadosCorporais = :IDDadosCorporais";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDDadosCorporais', $IDDadosCorporais);
        $stmt->execute();
        $dados = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$dados) {
            return ['message' => 'DadosCorporais não encontrado'];
        }
        
        return $dados;
    }
    
    public function getByUsu($IDUsuario) {
        
        global $pdo;
        $sql = "SELECT * FROM DadosCorporais WHERE IDUsuario = :IDUsuario AND Flag = 1 ORDER BY DataRegistro";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
       
    }

  
    public function registrar($IDUsuario, $DataRegistro, $Peso, $Altura, $PressaoMax = null, $PressaoMin = null, $Colesterol = null, $Glicose = null, $PercentualGordura = null, $MedidaAbdominal = null) {
    global $pdo;

    // Montar a query dinamicamente para inserir apenas os campos fornecidos
    $campos = ['IDUsuario', 'DataRegistro', 'Peso', 'Altura'];
    $valores = [':IDUsuario', ':DataRegistro', ':Peso', ':Altura'];
    $parametros = [
        ':IDUsuario' => $IDUsuario,
        ':DataRegistro' => $DataRegistro,
        ':Peso' => $Peso,
        ':Altura' => $Altura
    ];

    if (!is_null($PressaoMax)) {
        $campos[] = 'PressaoMax';
        $valores[] = ':PressaoMax';
        $parametros[':PressaoMax'] = $PressaoMax;
    }
    if (!is_null($PressaoMin)) {
        $campos[] = 'PressaoMin';
        $valores[] = ':PressaoMin';
        $parametros[':PressaoMin'] = $PressaoMin;
    }
    if (!is_null($Colesterol)) {
        $campos[] = 'Colesterol';
        $valores[] = ':Colesterol';
        $parametros[':Colesterol'] = $Colesterol;
    }
    if (!is_null($Glicose)) {
        $campos[] = 'Glicose';
        $valores[] = ':Glicose';
        $parametros[':Glicose'] = $Glicose;
    }
    if (!is_null($PercentualGordura)) {
        $campos[] = 'PercentualGordura';
        $valores[] = ':PercentualGordura';
        $parametros[':PercentualGordura'] = $PercentualGordura;
    }
    if (!is_null($MedidaAbdominal)) {
        $campos[] = 'MedidaAbdominal';
        $valores[] = ':MedidaAbdominal';
        $parametros[':MedidaAbdominal'] = $MedidaAbdominal;
    }

    // Adiciona a flag sempre como 1
    $campos[] = 'Flag';
    $valores[] = '1';

    // Monta a query final dinamicamente
    $sql = "INSERT INTO DadosCorporais (" . implode(',', $campos) . ") VALUES (" . implode(',', $valores) . ")";

    $stmt = $pdo->prepare($sql);

    foreach ($parametros as $key => &$val) {
        $stmt->bindParam($key, $val);
    }

    $stmt->execute();

    return $pdo->lastInsertId();
}



    public function update($IDDadosCorporais, $IDUsuario, $DataRegistro, $Peso, $Altura, $PressaoMax, $PressaoMin, $Colesterol, $Glicose, $PercentualGordura, $MedidaAbdominal) {
    global $pdo;

    // Verificando se o registro existe
    $sql = "SELECT * FROM DadosCorporais WHERE IDDadosCorporais = :IDDadosCorporais AND Flag = 1";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':IDDadosCorporais', $IDDadosCorporais);
    $stmt->execute();
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$dados) {
        return ['message' => 'Registro de Dados Corporais não encontrado'];
    }

    // Atualizando os dados corporais
    $sql = "UPDATE DadosCorporais 
            SET DataRegistro = :DataRegistro, Peso = :Peso, Altura = :Altura, 
                Pressao = :Pressao, Colesterol = :Colesterol, Glicose = :Glicose, 
                PercentualGordura = :PercentualGordura, MedidaAbdominal = :MedidaAbdominal
            WHERE IDDadosCorporais = :IDDadosCorporais AND Flag = 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':IDDadosCorporais', $IDDadosCorporais);
    $stmt->bindParam(':DataRegistro', $DataRegistro);
    $stmt->bindParam(':Peso', $Peso);
    $stmt->bindParam(':Altura', $Altura);
    $stmt->bindParam(':Pressao', $Pressao);
    $stmt->bindParam(':Colesterol', $Colesterol);
    $stmt->bindParam(':Glicose', $Glicose);
    $stmt->bindParam(':PercentualGordura', $PercentualGordura);
    $stmt->bindParam(':MedidaAbdominal', $MedidaAbdominal);
    $stmt->execute();

    // Retornar os dados atualizados
    $sqlSelect = "SELECT * FROM DadosCorporais WHERE IDDadosCorporais = :IDDadosCorporais";
    $stmtSelect = $pdo->prepare($sqlSelect);
    $stmtSelect->bindParam(':IDDadosCorporais', $IDDadosCorporais);
    $stmtSelect->execute();

    return $stmtSelect->fetch(PDO::FETCH_ASSOC);
}

    public function delete($IDDadosCorporais) {
        global $pdo;


        // Deletando o usuário (na verdade, desativando)
        $sql = "UPDATE DadosCorporais SET flag = 0 WHERE IDDadosCorporais = :IDDadosCorporais AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDDadosCorporais', $IDDadosCorporais);
        return $stmt->execute();
    }
}

?>