<?php

require_once './model/Ficha.php';
require_once './config/db.php';

class FichaController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Ficha WHERE flag = 1 ORDER BY nome";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($IDFicha) {
        global $pdo;
        $sql = "SELECT * FROM Ficha WHERE IDFicha = :IDFicha";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->execute();
        $ficha = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$ficha) {
            return ['message' => 'Ficha não encontrado'];
        }
        
        return $ficha;
    }
    
    public function getByUsuario($IDUsuario) {
        global $pdo;
        $sql = "SELECT * FROM Ficha WHERE IDUsuario = :IDUsuario AND flag = 1 ORDER BY nome";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->execute();
        $ficha = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$ficha) {
            return ['message' => 'Ficha não encontrado'];
        }
        
        return $ficha;
    }

    public function getAllByName($nome) {
        global $pdo;
        $sql = "SELECT * FROM Ficha WHERE Nome LIKE :Nome AND flag = 1 ORDER BY Nome";
        $stmt = $pdo->prepare($sql);
        $nome = "%$nome%";
        $stmt->bindParam(':nome', $nome);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

   

    public function registrar($IDUsuario,$Nome, $Descricao, $DataDeCadastro) {
        global $pdo;

        // Verificando se o email já existe
        

        // Registrando o novo usuário
       
        $sql = "INSERT INTO Ficha (IDUsuario,Nome, Descricao, DataDeCadastro, flag) 
                VALUES (:IDUsuario, :Nome, :Descricao, :DataDeCadastro, 1)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->bindParam(':DataDeCadastro', $DataDeCadastro);
        $stmt->execute();

        
        
         return [
        "IDFicha" => $pdo->lastInsertId(), // Obtém o ID inserido
        "IDUsuario" => $IDUsuario,
        "Nome" => $Nome,
        "Descricao" => $Descricao,
        "DataDeCadastro" => $DataDeCadastro
    ];
        
    
    }

    public function update($IDFicha, $IDUsuario,$Nome, $Descricao, $DataDeCadastro) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Ficha WHERE IDFicha = :IDFicha AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->execute();
        $ficha = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$ficha) {
            return ['message' => 'Ficha não encontrado'];
        }

        // Atualizando o usuário
        
        $sql = "UPDATE Ficha SET IDUsuario = :IDUsuario, Nome = :Nome, Descricao = :Descricao, DataDeCadastro = :DataDeCadastro
                WHERE IDFicha = :IDFicha AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->bindParam(':DataDeCadastro', $DataDeCadastro);
        $stmt->execute();

        return true;
    }

    public function delete($IDFicha) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Ficha WHERE IDFicha = :IDFicha AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->execute();
        $exercicio = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$exercicio) {
            return ['message' => 'Ficha não encontrado'];
        }

        // Deletando o usuário (na verdade, desativando)
        $sql = "UPDATE Ficha SET flag = 0 WHERE IDFicha = :IDFicha AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        return $stmt->execute();
    }
}

?>