<?php

require_once './model/Treino.php';
require_once './config/db.php';

class TreinoController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Treino WHERE Flag = 1 ORDER BY DataRealizada";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($IDTreino) {
        global $pdo;
        $sql = "SELECT * FROM Treino WHERE IDTreino = :IDTreino";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDTreino', $IDTreino);
        $stmt->execute();
        $treino = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$treino) {
            return ['message' => 'Treino não encontrado'];
        }
        
        return $treino;
    }
    
    public function getByDate($Data, $IDUsuario) {
        global $pdo;
        $sql = "SELECT Treino.IDTreino, Treino.Descricao, Treino.IDFicha, Treino.DataRealizada, Treino.Flag 
                FROM Treino 
                INNER JOIN Ficha ON Ficha.IDFicha = Treino.IDFicha
                WHERE Ficha.IDUsuario = :IDUsuario AND Treino.DataRealizada = :DataRealizada AND Treino.Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':DataRealizada', $Data);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->execute();
        $treino = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$treino) {
            return null;
        }
        
        return $treino;
    }
    
    public function getByUsuario($IDUsuario) {
        global $pdo;
        $sql = "SELECT Treino.IDTreino, Treino.Descricao, Treino.IDFicha, Treino.DataRealizada, Treino.Flag 
                FROM Treino 
                INNER JOIN Ficha ON Ficha.IDFicha = Treino.IDFicha
                WHERE Ficha.IDUsuario = :IDUsuario AND Treino.Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->execute();
        $ficha = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$ficha) {
            return ['message' => 'Ficha não encontrado'];
        }
        
        return $ficha;
    }



    public function registrar($IDFicha, $Descricao, $DataRealizada) {
        global $pdo;

    
       
        $sql = "INSERT INTO Treino (IDFicha, Descricao, DataRealizada, Flag) 
                VALUES (:IDFicha, :Descricao, :DataRealizada, 1)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->bindParam(':DataRealizada', $DataRealizada);
        $stmt->execute();

         return [
        "IDTreino" => $pdo->lastInsertId(), // Obtém o ID inserido
        "IDFicha" => $IDFicha,
        "DataRealizada" => $DataRealizada,
        "Descricao" => $Descricao
    ];
    }

    public function update($IDTreino, $IDFicha, $Descricao, $DataRealizada) {
        global $pdo;

      
        $sql = "UPDATE Treino SET IDFicha = :IDFicha, Descricao = :Descricao, DataRealizada = :DataRealizada
                WHERE IDTreino = :IDTreino AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->bindParam(':IDTreino', $IDTreino);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->bindParam(':DataRealizada', $DataRealizada);
        $stmt->execute();

        return true;
    }

    public function delete($IDTreino) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Treino WHERE IDTreino = :IDTreino AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDTreino', $IDTreino);
        $stmt->execute();
        $exercicio = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$exercicio) {
            return ['message' => 'Treino não encontrado'];
        }

        // Deletando o usuário (na verdade, desativando)
        $sql = "UPDATE Treino SET Flag = 0 WHERE IDTreino = :IDTreino AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDTreino', $IDTreino);
        return $stmt->execute();
    }
}

?>