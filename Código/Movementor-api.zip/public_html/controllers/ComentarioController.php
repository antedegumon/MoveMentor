<?php

require_once './config/db.php';

class ComentarioController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Comentario ORDER BY Lido";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($IDComentario) {
        
        global $pdo;
        $sql = "SELECT * FROM Comentario WHERE IDComentario = :IDComentario";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDComentario', $IDComentario);
        $stmt->execute();
        $dados = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$dados) {
            return ['message' => 'Comentario não encontrado'];
        }
        
        return $dados;
    }

  
    public function registrar($IDUsuario, $IDExercicio, $Comentario) {
        global $pdo;

  
        $sql = "INSERT INTO Comentario (IDUsuario, IDExercicio, Comentario, Lido, Resolvido) 
            VALUES (:IDUsuario, :IDExercicio, :Comentario, 0, 0)";
    
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDUsuario', $IDUsuario);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        $stmt->bindParam(':Comentario', $Comentario);
        $stmt->execute();
        
        // Retornar os dados recém-inseridos
        $lastInsertId = $pdo->lastInsertId();
        $sqlSelect = "SELECT * FROM Comentario WHERE IDComentario = :IDComentario";
        $stmtSelect = $pdo->prepare($sqlSelect);
        $stmtSelect->bindParam(':IDComentario', $lastInsertId);
        $stmtSelect->execute();
        
        return $stmtSelect->fetch(PDO::FETCH_ASSOC);
}


    public function update($IDComentario, $Lido, $Resolvido) {
    global $pdo;

    // Verificando se o registro existe
    $sql = "SELECT * FROM Comentario WHERE IDComentario = :IDComentario";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':IDComentario', $IDComentario);
    $stmt->execute();
    $dados = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$dados) {
        return ['message' => 'Registro de Comentario não encontrado'];
    }

    // Atualizando os dados corporais
    $sql = "UPDATE Comentario 
            SET Lido = :Lido, Resolvido = :Resolvido WHERE IDComentario = :IDComentario";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':Lido', $Lido);
    $stmt->bindParam(':Resolvido', $Resolvido);
    $stmt->bindParam(':IDComentario', $IDComentario);
    $stmt->execute();

    // Retornar os dados atualizados
    $sqlSelect = "SELECT * FROM Comentario WHERE IDComentario = :IDComentario";
    $stmtSelect = $pdo->prepare($sqlSelect);
    $stmtSelect->bindParam(':IDComentario', $IDComentario);
    $stmtSelect->execute();

    return $stmtSelect->fetch(PDO::FETCH_ASSOC);
}

    public function delete($IDComentario) {
        global $pdo;


        // Deletando o usuário (na verdade, desativando)
        $sql = "DELETE FROM Comentario WHERE IDComentario = :IDComentario";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDComentario', $IDComentario);
        return $stmt->execute();
    }
}

?>