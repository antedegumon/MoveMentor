<?php

require_once './config/db.php';

class AdminController {
    
    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Adm WHERE Flag = 1 ORDER BY Nome";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($IDAdm) {
        global $pdo;
        $sql = "SELECT * FROM Adm WHERE IDAdm = :IDAdm";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDAdm', $IDAdm);
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        return $admin ?: ['message' => 'Administrador não encontrado'];
    }

    public function autenticar($Email, $Senha) {
        global $pdo;
        $sql = "SELECT * FROM Adm WHERE Email = :Email AND Senha = :Senha AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Email', $Email);
        $stmt->bindParam(':Senha', $Senha);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function registrar($Nome, $Email, $Senha, $NivelAcesso) {
        global $pdo;
        $sql = "SELECT * FROM Adm WHERE Email = :Email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Email', $Email);
        $stmt->execute();
        if ($stmt->fetch(PDO::FETCH_ASSOC)) {
            return ['message' => 'E-mail já está em uso'];
        }
        
        $sql = "INSERT INTO Adm (Nome, Email, Senha, NivelAcesso, Flag) 
                VALUES (:Nome, :Email, :Senha, :NivelAcesso, 1)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':Email', $Email);
        $stmt->bindParam(':Senha', $Senha);
        $stmt->bindParam(':NivelAcesso', $NivelAcesso);
        $stmt->execute();

        return $pdo->lastInsertId();
    }

    public function update($IDAdm, $Nome, $Email, $Senha, $NivelAcesso) {
        global $pdo;
        $sql = "SELECT * FROM Adm WHERE IDAdm = :IDAdm AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDAdm', $IDAdm);
        $stmt->execute();
        if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
            return ['message' => 'Administrador não encontrado'];
        }
        
        $sql = "UPDATE Adm SET Nome = :Nome, Email = :Email, Senha = :Senha, NivelAcesso = :NivelAcesso 
                WHERE IDAdm = :IDAdm AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDAdm', $IDAdm);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':Email', $Email);
        $stmt->bindParam(':Senha', $Senha);
        $stmt->bindParam(':NivelAcesso', $NivelAcesso);
        $stmt->execute();

        return true;
    }

    public function delete($IDAdm) {
        global $pdo;
        $sql = "SELECT * FROM Adm WHERE IDAdm = :IDAdm AND Flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDAdm', $IDAdm);
        $stmt->execute();
        if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
            return ['message' => 'Administrador não encontrado'];
        }
        
        $sql = "UPDATE Adm SET Flag = 0 WHERE IDAdm = :IDAdm";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDAdm', $IDAdm);
        return $stmt->execute();
    }
}

?>