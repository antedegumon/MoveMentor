<?php

require_once './model/Usuario.php';
require_once './config/db.php';

class UsuarioController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Usuario WHERE flag = 1 ORDER BY nome";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($idUsuario) {
        global $pdo;
        $sql = "SELECT * FROM Usuario WHERE idUsuario = :idUsuario";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$usuario) {
            return ['message' => 'Usuário não encontrado'];
        }
        
        return $usuario;
    }

    public function getAllByName($nome) {
        global $pdo;
        $sql = "SELECT * FROM Usuario WHERE nome LIKE :nome AND flag = 1 ORDER BY nome";
        $stmt = $pdo->prepare($sql);
        $nome = "%$nome%";
        $stmt->bindParam(':nome', $nome);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getReport() {
        global $pdo;
        $sql = "SELECT nome, genero FROM Usuario WHERE flag = 1 ORDER BY nome";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $report = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso não existam registros
        if (!$report) {
            return ['message' => 'Nenhum usuário encontrado'];
        }
        
        return $report;
    }

    public function autenticar($email, $senha) {
        global $pdo;
        $sql = "SELECT * FROM Usuario WHERE email = :email AND senha = :senha AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Se o usuário não for encontrado ou a senha for inválida
        //if (!$usuario || !password_verify($senha, $usuario['senha'])) {
       //     return ['message' => 'Credenciais inválidas'];
       // }

        // Se a autenticação for bem-sucedida
        return $usuario;
    }

    public function registrar($nome, $email, $senha, $dataNascimento, $genero) {
        global $pdo;

        // Verificando se o email já existe
        $sql = "SELECT * FROM Usuario WHERE Email = :Email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Email', $email);
        $stmt->execute();
        if ($stmt->fetch(PDO::FETCH_ASSOC)) {
            return ['message' => 'E-mail já está em uso'];
        }

        // Registrando o novo usuário
        //$senhaHash = password_hash($senha, PASSWORD_DEFAULT);
        $sql = "INSERT INTO Usuario (Nome, Email, Senha, DataNascimento, Genero, Flag) 
                VALUES (:Nome, :Email, :Senha, :DataNascimento, :Genero, 1)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Nome', $nome);
        $stmt->bindParam(':Email', $email);
        $stmt->bindParam(':Senha', $senha);
        $stmt->bindParam(':DataNascimento', $dataNascimento);
        $stmt->bindParam(':Genero', $genero);
        $stmt->execute();

        return $pdo->lastInsertId();
    }

    public function update($idUsuario, $nome, $email, $senha, $dataNascimento, $genero) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Usuario WHERE idUsuario = :idUsuario AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$usuario) {
            return ['message' => 'Usuário não encontrado'];
        }

        // Atualizando o usuário
       
        $sql = "UPDATE Usuario SET nome = :nome, email = :email, senha = :senha, 
                dataNascimento = :dataNascimento, genero = :genero 
                WHERE idUsuario = :idUsuario AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);
        $stmt->bindParam(':dataNascimento', $dataNascimento);
        $stmt->bindParam(':genero', $genero);
        $stmt->execute();

        return true;
    }

    public function delete($idUsuario) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Usuario WHERE idUsuario = :idUsuario AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$usuario) {
            return ['message' => 'Usuário não encontrado'];
        }

        // Deletando o usuário (na verdade, desativando)
        $sql = "UPDATE Usuario SET flag = 0 WHERE idUsuario = :idUsuario";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario);
        return $stmt->execute();
    }
}

?>