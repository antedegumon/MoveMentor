<?php

require_once './model/Exercicio.php';
require_once './config/db.php';

class ExercicioController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Exercicio WHERE flag = 1 ORDER BY nome";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($IDExercicio) {
        global $pdo;
        $sql = "SELECT * FROM Exercicio WHERE IDExercicio = :IDExercicio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$usuario) {
            return ['message' => 'Usuário não encontrado'];
        }
        
        return $usuario;
    }

    public function getAllByName($nome) {
        global $pdo;
        $sql = "SELECT * FROM Exercicio WHERE nome LIKE :nome AND flag = 1 ORDER BY nome";
        $stmt = $pdo->prepare($sql);
        $nome = "%$nome%";
        $stmt->bindParam(':nome', $nome);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

   

    public function registrar($Nome, $Descricao, $IDCategoria, $Imagem, $Instrucoes) {
        global $pdo;

        // Verificando se o email já existe
        $sql = "SELECT * FROM Exercicio WHERE nome = :Nome";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->execute();
        if ($stmt->fetch(PDO::FETCH_ASSOC)) {
            return ['message' => 'Exercicio já cadastrado'];
        }

        // Registrando o novo usuário
       
        $sql = "INSERT INTO Exercicio (Nome, Descricao, IDCategoria, Imagem, Instrucoes, flag) 
                VALUES (:Nome, :Descricao, :IDCategoria, :Imagem, :Instrucoes, 1)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->bindParam(':IDCategoria', $IDCategoria);
        $stmt->bindParam(':Imagem', $Imagem);
        $stmt->bindParam(':Instrucoes', $Instrucoes);
        $stmt->execute();

        
        
         return [
        "IDExercicio" => $pdo->lastInsertId(), // Obtém o ID inserido
        "IDCategoria" => $IDCategoria,
        "Nome" => $Nome,
        "Descricao" => $Descricao
    ];
    }

    public function update($IDExercicio, $Nome, $Descricao, $IDCategoria, $Imagem, $Instrucoes) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Exercicio WHERE IDExercicio = :IDExercicio AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        $stmt->execute();
        $exercicio = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$exercicio) {
            return ['message' => 'Exercicio não encontrado'];
        }

        // Atualizando o usuário
        
        $sql = "UPDATE Exercicio SET Nome = :Nome, Descricao = :Descricao, IDCategoria = :IDCategoria, 
                Imagem = :Imagem, Instrucoes = :Instrucoes 
                WHERE IDExercicio = :IDExercicio AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->bindParam(':IDCategoria', $IDCategoria);
        $stmt->bindParam(':Imagem', $Imagem);
        $stmt->bindParam(':Instrucoes', $Instrucoes);
        $stmt->execute();

        return true;
    }

    public function delete($IDExercicio) {
        global $pdo;

        // Verificando se o usuário existe
        $sql = "SELECT * FROM Exercicio WHERE IDExercicio = :IDExercicio AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        $stmt->execute();
        $exercicio = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$exercicio) {
            return ['message' => 'Exercicio não encontrado'];
        }

        // Deletando o usuário (na verdade, desativando)
        $sql = "UPDATE Exercicio SET flag = 0 WHERE IDExercicio = :IDExercicio AND flag = 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        return $stmt->execute();
    }
}

?>