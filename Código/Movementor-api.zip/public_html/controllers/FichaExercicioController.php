<?php

require_once './model/FichaExercicio.php';
require_once './config/db.php';

class FichaExercicioController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Fichaexercicio";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    
    
    public function getByFicha($IDFicha) {
        global $pdo;
        $sql = "SELECT * FROM Fichaexercicio WHERE IDFicha = :IDFicha";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->execute();
        $fichaexercicio = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$fichaexercicio) {
            return ['message' => '$fichaexercicio não encontrado'];
        }
        
        return $fichaexercicio;
    }

   

   

    public function registrar($IDFicha,$IDExercicio, $Series, $Repeticoes, $Tempo) {
        global $pdo;

      
       
        $sql = "INSERT INTO Fichaexercicio (IDFicha,IDExercicio, Series, Repeticoes, Tempo) 
                VALUES (:IDFicha, :IDExercicio, :Series, :Repeticoes, :Tempo)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        $stmt->bindParam(':Series', $Series);
        $stmt->bindParam(':Repeticoes', $Repeticoes);
        $stmt->bindParam(':Tempo', $Tempo);
        $stmt->execute();

        return $pdo->lastInsertId();
    }

   

    public function delete($IDFicha) {
        global $pdo;

        

        // Deletando o usuário (na verdade, desativando)
        $sql = "DELETE FROM Fichaexercicio WHERE IDFicha = :IDFicha";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDFicha', $IDFicha);
        return $stmt->execute();
    }
}

?>