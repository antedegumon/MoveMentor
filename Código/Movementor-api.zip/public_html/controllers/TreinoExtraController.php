<?php

//require_once './model/FichaExercicio.php';
require_once './config/db.php';

class TreinoExtraController {

    public function getAll() {
        global $pdo;
        $sql = "SELECT * FROM Treinoextra";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    
    
    public function getByFicha($IDFicha) {
        global $pdo;
        $sql = "SELECT * FROM Treinoextra WHERE IDTreino = :IDTreino";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDTreino', $IDFicha);
        $stmt->execute();
        $fichaexercicio = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Caso o usuário não seja encontrado
        if (!$fichaexercicio) {
            return ['message' => 'Treinoextra não encontrado'];
        }
        
        return $fichaexercicio;
    }

   

   

    public function registrar($IDTreino,$IDExercicio, $Situacao, $Series, $Repeticoes, $Tempo) {
        global $pdo;

      
       
        $sql = "INSERT INTO Treinoextra (IDTreino,IDExercicio, Situacao, Series, Repeticoes, Tempo) 
                VALUES (:IDTreino,:IDExercicio, :Situacao, :Series, :Repeticoes, :Tempo)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDTreino', $IDTreino);
        $stmt->bindParam(':IDExercicio', $IDExercicio);
        $stmt->bindParam(':Situacao', $Situacao);
        $stmt->bindParam(':Series', $Series);
        $stmt->bindParam(':Repeticoes', $Repeticoes);
        $stmt->bindParam(':Tempo', $Tempo);
        $stmt->execute();

        return $pdo->lastInsertId();
    }

   

    public function delete($IDTreino) {
        global $pdo;

        

        // Deletando o usuário (na verdade, desativando)
        $sql = "DELETE FROM Treinoextra WHERE IDTreino = :IDTreino";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':IDTReino', $IDTreino);
        return $stmt->execute();
    }
}

?>