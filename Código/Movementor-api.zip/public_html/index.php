<?php


// Exibir erros no ambiente de desenvolvimento
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Captura de erros fatais para evitar erro 500
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error !== null) {
        http_response_code(500);
        echo json_encode(["error" => "Ocorreu um erro interno no servidor. Tente novamente mais tarde."]);
    }
});

// Captura exceções não tratadas
set_exception_handler(function ($e) {
    http_response_code(500);
    echo json_encode(["error" => "Erro inesperado: " . $e->getMessage()]);
});

// Captura erros padrão do PHP (avisos, warnings, etc.)
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode([
        "error" => "Erro no servidor",
        "details" => "$errstr em $errfile na linha $errline"
    ]);
});

header("Access-Control-Allow-Origin: *"); // Permite todas as origens
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE"); // Métodos permitidos
header("Access-Control-Allow-Headers: Content-Type, Authorization"); // Cabeçalhos permitidos






// Definindo as rotas
require_once 'routes/routes.php';
?>
