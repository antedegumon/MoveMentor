<?php

class Usuario {
    public $idUsuario;
    public $nome;
    public $email;
    public $senha;
    public $dataNascimento;
    public $genero;
    public $flag;

    public function __construct($nome, $email, $senha, $dataNascimento, $genero, $flag = 1) {
        $this->nome = $nome;
        $this->email = $email;
        $this->senha = $senha; // Use senha hash no controller ao criar/atualizar
        $this->dataNascimento = $dataNascimento;
        $this->genero = $genero;
        $this->flag = $flag;
    }
}
?>
