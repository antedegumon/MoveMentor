<?php

class FichaExercicio {
    public $idFicha;
    public $idExercicio;
    public $series;
    public $repeticoes;
    public $tempo;

    public function __construct($idFicha, $idExercicio, $series, $repeticoes, $tempo) {
        $this->idFicha = $idFicha;
        $this->idExercicio = $idExercicio;
        $this->series = $series;
        $this->repeticoes = $repeticoes;
        $this->tempo = $tempo;
    }
}
?>
