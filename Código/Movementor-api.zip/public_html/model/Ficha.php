<?php

class Exercicio {
    public $idFicha;
    public $idUsuario;
    public $nome;
    public $descricao;
    public $dataDeCadastro;
    public $flag;

    public function __construct($nome, $email, $senha, $dataNascimento, $genero, $flag = 1) {
        $this->idFicha = $idFicha;
        $this->idUsuario = $idUsuario;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->dataDeCadastro = $dataDeCadastro;
        $this->flag = $flag;
    }
}
?>
