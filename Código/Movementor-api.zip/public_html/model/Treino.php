<?php

class Treino {
    public $idTreino;
    public $idFicha;
    public $descricao;
    public $dataRealizada;
    public $flag;

    public function __construct($idTreino, $idFicha, $descricao, $dataRealizada, $flag = 1) {
        $this->idFicha = $idFicha;
        $this->idTreino = $idTreino;
        $this->descricao = $descricao;
        $this->dataRealizada = $dataRealizada;
        $this->flag = $flag;
    }
}
?>
