<?php

class Exercicio {
    public $idExercicio;
    public $nome;
    public $descricao;
    public $idCategoria;
    public $imagem;
    public $instrucao;
    public $flag;

    public function __construct($nome, $email, $senha, $dataNascimento, $genero, $flag = 1) {
        $this->idExercicio = $idExercicio;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->idCategoria = $idCategoria; // Use senha hash no controller ao criar/atualizar
        $this->imagem = $imagem;
        $this->instrucao = $instrucao;
        $this->flag = $flag;
    }
}
?>
