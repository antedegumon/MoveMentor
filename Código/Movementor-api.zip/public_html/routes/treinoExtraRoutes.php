<?php

require_once './controllers/TreinoExtraController.php';

$treinoExtraController = new TreinoExtraController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        
       
        
         if (isset($requestUri[1]) && $requestUri[1] == 'treino' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $treino = $treinoExtraController->getByFicha($requestUri[2]);
            echo json_encode($treino ?: ['message' => 'Treino não encontrado']);
            break;
        }

      

        
        $treino = $treinoExtraController->getAll();
        echo json_encode($treino);
        break;

    case 'POST':
        // Caso de registro de novo usuário
        $data = json_decode(file_get_contents("php://input"));
        $id = $treinoExtraController->registrar($data->IDTreino, $data->IDExercicio, $data->Situacao, $data->Series, $data->Repeticoes, $data->Tempo);
        echo json_encode(['$IDTreino' => $id]);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        
        $data = json_decode(file_get_contents("php://input"));
        $result = $treinoExtraController->delete($data->IDFicha);
        echo json_encode(['message' => $result ? 'Ficha deletada com sucesso' : 'Erro ao deletar Ficha']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
