<?php

require_once './controllers/ComentarioController.php';

$comentarioController = new ComentarioController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        // Verificar se a URL corresponde à rota para autenticação
       

        // Caso de consulta de usuário por ID
        if (isset($requestUri[1]) && $requestUri[1] == 'byid' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $comentario = $comentarioController->getById($requestUri[2]);
            echo json_encode($comentario ?: ['message' => 'Corrida não encontrado']);
            break;
        }

        

        
        $comentario = $comentarioController->getAll();
        echo json_encode($comentario);
        break;

    case 'POST':
        // Caso de registro de novo usuário
        $data = json_decode(file_get_contents("php://input"));
        $id = $comentarioController->registrar($data->IDUsuario, $data->IDExercicio, $data->Comentario);
        echo json_encode($id);
        break;

    case 'PUT':
        // Caso de atualização de usuário
        $data = json_decode(file_get_contents("php://input"));
        $result = $comentarioController->update($data->IDComentario, $data->Lido, $data->Resolvido);
        echo json_encode(['message' => $result ? 'Comentario atualizado com sucesso' : 'Erro ao atualizar Comentario']);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        
        if (isset($requestUri[1])) {
           // echo "Estamos por id...<br>"; // Depuração
            $comentario = $comentarioController->delete($requestUri[1]);
            echo json_encode($comentario ?: ['message' => 'Comentario não encontrado']);
            break;
        }
        
        $data = json_decode(file_get_contents("php://input"));
        $result = $comentarioController->delete($data->IDCorrida);
        echo json_encode(['message' => $result ? 'Comentario deletado com sucesso' : 'Erro ao deletar Comentario']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
