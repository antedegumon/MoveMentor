<?php

$requestUri = explode('/', trim($_SERVER['REQUEST_URI'], '/')); // Divide a URL

switch($requestUri[0]) {
    case 'usuario':
        require_once 'usuarioRoutes.php';
        break;
    
    case 'exercicio':
        require_once 'exercicioRoutes.php';
        break;
        
    case 'ficha':
        require_once 'fichaRoutes.php';
        break;
        
    case 'fichaexercicio':
        require_once 'fichaExercicioRoutes.php';
        break;
        
    case 'treino':
        require_once 'treinoRoutes.php';
        break;
        
    case 'treinoextra':
        require_once 'treinoExtraRoutes.php';
        break;
    
    case 'corrida':
        require_once 'corridaRoutes.php';
        break;
        
    case 'corridacoordenada':
        require_once 'corridaCoordenadaRoutes.php';
        break;
        
    case 'dadoscorporais':
        require_once 'dadosCorporaisRoutes.php';
        break;
        
    case 'comentario':
        require_once 'comentarioRoutes.php';
        break;
        
    case 'adm':
        require_once 'adminRoutes.php';
        break;
        
        


}



?>