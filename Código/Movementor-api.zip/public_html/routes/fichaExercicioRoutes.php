<?php

require_once './controllers/FichaExercicioController.php';

$fichaExercicioController = new FichaExercicioController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        
       
        
         if (isset($requestUri[1]) && $requestUri[1] == 'ficha' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $ficha = $fichaExercicioController->getByFicha($requestUri[2]);
            echo json_encode($ficha ?: ['message' => 'Ficha não encontrado']);
            break;
        }

      

        
        $ficha = $fichaExercicioController->getAll();
        echo json_encode($ficha);
        break;

    case 'POST':
        // Caso de registro de novo usuário
        $data = json_decode(file_get_contents("php://input"));
        $id = $fichaExercicioController->registrar($data->IDFicha, $data->IDExercicio, $data->Series, $data->Repeticoes, $data->Tempo);
        echo json_encode(['$IDFicha' => $id]);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        
        $data = json_decode(file_get_contents("php://input"));
        $result = $fichaExercicioController->delete($data->IDFicha);
        echo json_encode(['message' => $result ? 'Ficha deletada com sucesso' : 'Erro ao deletar Ficha']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
