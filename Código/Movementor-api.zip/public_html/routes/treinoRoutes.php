<?php

require_once './controllers/TreinoController.php';

$treinoController = new TreinoController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        // Verificar se a URL corresponde à rota para autenticação
       

        // Caso de consulta de usuário por ID
        if (isset($requestUri[1]) && $requestUri[1] == 'byid' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $treino = $treinoController->getById($requestUri[2]);
            echo json_encode($treino ?: ['message' => 'Treino não encontrado']);
            break;
        }
        
        if (isset($requestUri[1]) && $requestUri[1] == 'bydate' && isset($requestUri[2]) && isset($requestUri[3])) {
           // echo "Estamos por id...<br>"; // Depuração
            $treino = $treinoController->getByDate($requestUri[2], $requestUri[3]);
            echo json_encode($treino ?: null);
            break;
        }
        
         if (isset($requestUri[1]) && $requestUri[1] == 'usu' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $treino = $treinoController->getByUsuario($requestUri[2]);
            echo json_encode($treino ?: ['message' => 'Treino não encontrado']);
            break;
        }

 
        
        $treino = $treinoController->getAll();
        echo json_encode($treino);
        break;

    case 'POST':
        // Caso de registro de novo usuário
        $data = json_decode(file_get_contents("php://input"));
        $id = $treinoController->registrar($data->IDFicha, $data->Descricao, $data->DataRealizada);
        echo json_encode($id);
        break;

    case 'PUT':
        // Caso de atualização de usuário
        $data = json_decode(file_get_contents("php://input"));
        $result = $treinoController->update($data->IDTreino, $data->IDFicha, $data->Descricao, $data->DataRealizada);
        echo json_encode(['message' => $result ? 'Treino atualizado com sucesso' : 'Erro ao atualizar Treino']);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        
        if (isset($requestUri[1])) {
           // echo "Estamos por id...<br>"; // Depuração
            $treino = $treinoController->delete($requestUri[1]);
            echo json_encode($treino ?: ['message' => 'treino não encontrado']);
            break;
        }
        
        $data = json_decode(file_get_contents("php://input"));
        $result = $treinoController->delete($data->IDTreino);
        echo json_encode(['message' => $result ? 'Treino deletada com sucesso' : 'Erro ao deletar Treino']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
