<?php

require_once './controllers/AdminController.php';

$usuarioController = new AdminController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        // Verificar se a URL corresponde à rota para autenticação
        if (isset($requestUri[1]) && $requestUri[1] == 'autenticar' && isset($requestUri[2]) && isset($requestUri[3])) {
            //echo "Estamos autenticando...<br>"; // Depuração
            // Aqui, $requestUri[1] será o email e $requestUri[2] será a senha
            $email = $requestUri[2];
            $senha = $requestUri[3];
            
            $usuario = $usuarioController->autenticar($email, $senha);
            echo json_encode($usuario ?: ['message' => 'Credenciais inválidas']);
            break; // Impede que o fluxo passe para as próximas condições
        }

        // Caso de consulta de usuário por ID
        if (isset($requestUri[1]) && $requestUri[1] == 'byid' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $usuario = $usuarioController->getById($requestUri[2]);
            echo json_encode($usuario ?: ['message' => 'Usuário não encontrado']);
            break;
        }

        // Caso de consulta de usuários por nome
        if (isset($requestUri[1]) && $requestUri[1] == 'byname' && isset($requestUri[2])) {
            //echo "Estamos por nome...<br>"; // Depuração
            $usuarios = $usuarioController->getAllByName($requestUri[2]);
            echo json_encode($usuarios);
            break;
        }

       

        // Caso de consulta de todos os usuários
        //echo "Estamos tudo...<br>"; // Depuração
        
        $usuarios = $usuarioController->getAll();
        echo json_encode($usuarios);
        break;

    case 'POST':
        // Caso de registro de novo usuário
        $data = json_decode(file_get_contents("php://input"));
        $id = $usuarioController->registrar($data->Nome, $data->Email, $data->Senha,  $data->NivelAcesso);
        echo json_encode(['idUsuario' => $id]);
        break;

    case 'PUT':
        // Caso de atualização de usuário
        $data = json_decode(file_get_contents("php://input"));
        $result = $usuarioController->update($data->idUsuario, $data->nome, $data->email, $data->senha, $data->dataNascimento, $data->genero);
        echo json_encode(['message' => $result ? 'Usuário atualizado com sucesso' : 'Erro ao atualizar usuário']);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        $data = json_decode(file_get_contents("php://input"));
        $result = $usuarioController->delete($data->idUsuario);
        echo json_encode(['message' => $result ? 'Usuário deletado com sucesso' : 'Erro ao deletar usuário']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
