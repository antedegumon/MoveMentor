<?php

require_once './controllers/DadosCorporaisController.php';

$dadosCorporaisController = new DadosCorporaisController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        // Verificar se a URL corresponde à rota para autenticação
       

        // Caso de consulta de usuário por ID
        if (isset($requestUri[1]) && $requestUri[1] == 'byid' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $dados = $dadosCorporaisController->getById($requestUri[2]);
            echo json_encode($dados ?: ['message' => 'Corrida não encontrado']);
            break;
        }
        
        if (isset($requestUri[1]) && $requestUri[1] == 'usu' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $dados = $dadosCorporaisController->getByUsu($requestUri[2]);
            echo json_encode($dados ?: ['message' => 'Corrida não encontrado']);
            break;
        }

        // Caso de consulta de usuários por nome
        if (isset($requestUri[1]) && $requestUri[1] == 'byname' && isset($requestUri[2])) {
            //echo "Estamos por nome...<br>"; // Depuração
            $dados = $dadosCorporaisController->getAllByName($requestUri[2]);
            echo json_encode($dados);
            break;
        }

       

        // Caso de consulta de todos os usuários
        //echo "Estamos tudo...<br>"; // Depuração
        
        $dados = $dadosCorporaisController->getAll();
        echo json_encode($dados);
        break;

    case 'POST':
   case 'POST':
    // Caso de registro de novo usuário
    $data = json_decode(file_get_contents("php://input"));

    // Definir valores padrão para os campos opcionais
    $id = $dadosCorporaisController->registrar(
        $data->IDUsuario, 
        $data->DataRegistro, 
        $data->Peso, 
        $data->Altura, 
        $data->PressaoMax ?? null, 
        $data->PressaoMin ?? null, 
        $data->Colesterol ?? null, 
        $data->Glicose ?? null, 
        $data->PercentualGordura ?? null, 
        $data->MedidaAbdominal ?? null
    );

    echo json_encode($id);
    break;

    case 'PUT':
        // Caso de atualização de usuário
        $data = json_decode(file_get_contents("php://input"));
        $result = $dadosCorporaisController->update($data->IDDadosCorporais, $data->IDUsuario, $data->DataRegistro, $data->Peso, $data->Altura, $data->PressaoMax, $data->PressaoMin, $data->Colesterol, $data->Glicose, $data->PercentualGordura, $data->MedidaAbdominal);
        echo json_encode(['message' => $result ? 'Corrida atualizado com sucesso' : 'Erro ao atualizar Corrida']);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        
        if (isset($requestUri[1])) {
           // echo "Estamos por id...<br>"; // Depuração
            $corrida = $dadosCorporaisController->delete($requestUri[1]);
            echo json_encode($corrida ?: ['message' => 'Corrida não encontrado']);
            break;
        }
        
        $data = json_decode(file_get_contents("php://input"));
        $result = $dadosCorporaisController->delete($data->IDCorrida);
        echo json_encode(['message' => $result ? 'Corrida deletado com sucesso' : 'Erro ao deletar Corrida']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
