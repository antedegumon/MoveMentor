<?php

require_once './controllers/CorridaCoordenadaController.php';

$corridaCoordenadaController = new CorridaCoordenadaController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        
       
        
         if (isset($requestUri[1]) && $requestUri[1] == 'corrida' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $coordenada = $corridaCoordenadaController->getByCorrida($requestUri[2]);
            echo json_encode($coordenada ?: ['message' => 'Coordenada não encontrado']);
            break;
        }

      

        
        $coordenada = $corridaCoordenadaController->getAll();
        echo json_encode($coordenada);
        break;

    case 'POST':
        // Caso de registro de novo usuário
        $data = json_decode(file_get_contents("php://input"));
        $id = $corridaCoordenadaController->registrar($data->IDCorrida, $data->Ordem, $data->Latitude, $data->Longitude);
        echo json_encode(['$IDTreino' => $id]);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        
         if (isset($requestUri[1])) {
           // echo "Estamos por id...<br>"; // Depuração
            $coordenada = $corridaCoordenadaController->delete($requestUri[1]);
            echo json_encode($coordenada ?: ['message' => 'Corrida não encontrado']);
            break;
        }
        
        $data = json_decode(file_get_contents("php://input"));
        $result = $corridaCoordenadaController->delete($data->IDCorrida);
        echo json_encode(['message' => $result ? 'Ficha deletada com sucesso' : 'Erro ao deletar Ficha']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
