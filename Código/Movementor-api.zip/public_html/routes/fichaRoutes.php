<?php

require_once './controllers/FichaController.php';

$fichaController = new FichaController();

header('Content-Type: application/json');

// Roteamento das ações

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        // Verificar se a URL corresponde à rota para autenticação
       

        // Caso de consulta de usuário por ID
        if (isset($requestUri[1]) && $requestUri[1] == 'byid' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $ficha = $fichaController->getById($requestUri[2]);
            echo json_encode($ficha ?: ['message' => 'Ficha não encontrado']);
            break;
        }
        
         if (isset($requestUri[1]) && $requestUri[1] == 'usu' && isset($requestUri[2])) {
           // echo "Estamos por id...<br>"; // Depuração
            $ficha = $fichaController->getByUsuario($requestUri[2]);
            echo json_encode($ficha ?: ['message' => 'Ficha não encontrado']);
            break;
        }

        // Caso de consulta de usuários por nome
        if (isset($requestUri[1]) && $requestUri[1] == 'byname' && isset($requestUri[2])) {
            //echo "Estamos por nome...<br>"; // Depuração
            $ficha = $fichaController->getAllByName($requestUri[2]);
            echo json_encode($ficha);
            break;
        }


       

        // Caso de consulta de todos os usuários
        //echo "Estamos tudo...<br>"; // Depuração
        
        $ficha = $fichaController->getAll();
        echo json_encode($ficha);
        break;

    case 'POST':
        // Caso de registro de novo usuário
        $data = json_decode(file_get_contents("php://input"));
        $id = $fichaController->registrar($data->IDUsuario, $data->Nome, $data->Descricao, $data->DataDeCadastro);
        echo json_encode($id);
        break;

    case 'PUT':
        // Caso de atualização de usuário
        $data = json_decode(file_get_contents("php://input"));
        $result = $fichaController->update($data->IDFicha, $data->IDUsuario, $data->Nome, $data->Descricao, $data->DataDeCadastro);
        echo json_encode(['message' => $result ? 'Ficha atualizado com sucesso' : 'Erro ao atualizar Ficha']);
        break;

    case 'DELETE':
        // Caso de exclusão de usuário
        
        if (isset($requestUri[1])) {
           // echo "Estamos por id...<br>"; // Depuração
            $ficha = $fichaController->delete($requestUri[1]);
            echo json_encode($ficha ?: ['message' => 'Corrida não encontrado']);
            break;
        }
        
        $data = json_decode(file_get_contents("php://input"));
        $result = $fichaController->delete($data->IDFicha);
        echo json_encode(['message' => $result ? 'Ficha deletada com sucesso' : 'Erro ao deletar Ficha']);
        break;

    default:
        echo json_encode(['message' => 'Método não suportado']);
        break;
}
?>
