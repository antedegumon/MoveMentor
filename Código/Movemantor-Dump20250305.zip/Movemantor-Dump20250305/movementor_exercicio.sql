-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: movementor
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exercicio`
--

DROP TABLE IF EXISTS `exercicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercicio` (
  `IDExercicio` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(255) NOT NULL,
  `Descricao` text NOT NULL,
  `IDCategoria` int(11) NOT NULL,
  `Imagem` varchar(255) DEFAULT NULL,
  `Instrucoes` varchar(255) NOT NULL,
  `Flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`IDExercicio`),
  KEY `IDCategoria` (`IDCategoria`),
  CONSTRAINT `Exercicio_ibfk_1` FOREIGN KEY (`IDCategoria`) REFERENCES `categoria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercicio`
--

LOCK TABLES `exercicio` WRITE;
/*!40000 ALTER TABLE `exercicio` DISABLE KEYS */;
INSERT INTO `exercicio` VALUES (11,'Corrida','Corrida ao ar livre ou na esteira.',1,NULL,'Correr por 30 minutos.',0),(12,'Agachamento','Exercício para fortalecer as pernas e glúteos, pode ser feito com ou sem pesos',2,'https://teal-mink-565589.hostingersite.com/admin/uploads/agachamento.jpg','Fazer 3 séries de 12 repetições.',1),(13,'Flexão','Exercício para fortalecer o peitoral e os braços.',2,'https://teal-mink-565589.hostingersite.com/admin/uploads/flexao.webp','Fazer 3 séries de 15 repetições.',1),(14,'Alongamento de Pernas','Alongamento básico para as pernas.',6,'https://teal-mink-565589.hostingersite.com/admin/uploads/alonguePerna.jpg','Alongar por 30 segundos cada perna.',1),(15,'Yoga Básico','Sequência básica de posturas de yoga.',3,NULL,'Realizar a sequência por 20 minutos.',1),(16,'Prancha','Exercício para fortalecer o core.',5,'https://teal-mink-565589.hostingersite.com/admin/uploads/prancha.jpg','Manter a posição por 1 minuto.',1),(17,'Ponte','Exercício para fortalecer os glúteos e core.',5,'https://teal-mink-565589.hostingersite.com/admin/uploads/ponte.jpg','Fazer 3 séries de 10 repetições.',1),(18,'Polichinelo','Exercício de cardio para aquecimento.',1,'https://teal-mink-565589.hostingersite.com/admin/uploads/Polichinelo.webp','Fazer 2 séries de 50 repetições.',1),(19,'Elevação de Perna','Exercício para fortalecer o abdômen.',2,'https://teal-mink-565589.hostingersite.com/admin/uploads/elevPerna.jpg','Fazer 3 séries de 15 repetições.',1),(20,'Alongamento de Braços','Alongamento básico para os braços.',6,'https://teal-mink-565589.hostingersite.com/admin/uploads/alongBraco.jpg','Alongar por 30 segundos cada braço.',1),(21,'Supino','Exercício para fortalecimento do peito.',2,NULL,'Fazer 3 séries de 12 repetições.',1),(29,'Rosca Concentrada','Exercicio de Biceps',2,'https://teal-mink-565589.hostingersite.com/admin/uploads/roscCOnc.jpg','Levante o peso com um braço sem mecher o cutuvelo',1),(30,'Crucifixo','Exercício de peito',2,'https://teal-mink-565589.hostingersite.com/admin/uploads/FILE-20170531-1653NV23BHDWHBLM.jpg','Faça 3 séries de 12 repetições cada uma',1),(31,'Triceps corda','treino de triceps',2,'https://teal-mink-565589.hostingersite.com/admin/uploads/roscCOnc.jpg','faça 3 de 12',1),(32,'Barra Fixa','Exercicio para fortalecimento das costas',2,'https://teal-mink-565589.hostingersite.com/admin/uploads/imagem_2025-03-04_182721056.png','Se pendure na barra e puxe seu corpo para cima',1);
/*!40000 ALTER TABLE `exercicio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-05 15:44:08
