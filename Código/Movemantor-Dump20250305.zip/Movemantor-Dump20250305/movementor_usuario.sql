-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: movementor
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `IDUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Senha` varchar(255) NOT NULL,
  `DataNascimento` date NOT NULL,
  `Genero` enum('Masculino','Feminino','Outro') NOT NULL,
  `Flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`IDUsuario`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Gabriel Spagnol','user1@movementor.com','senha1','2005-02-05','Masculino',1),(2,'user2','user2@movementor.com','senha2','2006-02-16','Feminino',1),(3,'user3','user3@movementor.com','$2y$10$oXwaYeKsJaS9YVDj4kZq1eJld/OqSpwq.ZNBkV5AE2dFY6WZ0104i','2003-02-03','Masculino',1),(4,'leandro','leandrin1207@gmail.com','22012007','2007-01-22','Masculino',1),(5,'Matheus','matheusbpa2012@gmail.com','22012007','2010-02-02','Masculino',1),(6,'Gabriell','gabs@gmail.com','123123','2015-02-03','Masculino',1),(7,'nomeTeste','emailTeste12@email.com','senhaTeste12345678','2025-02-05','Masculino',1),(8,'nome','email','senha','2002-02-20','Masculino',1),(9,'gabriel','gabriel@email.com','senha','2025-02-13','Masculino',1),(10,'Shirley','shirley@email.com','123','1971-03-14','Feminino',1),(11,'nome','email2','senha1','2025-03-01','Masculino',1),(12,'Usuarioteste','usuteste@movementor.com','senha1234','2000-03-22','Masculino',1),(13,'Leandro Pessoa','leandrobpa2007@gmail.com','keypass123','2007-01-22','Masculino',1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-05 15:44:09
